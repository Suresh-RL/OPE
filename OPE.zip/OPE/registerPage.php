<?php 
include('header.php'); 
include('connection.php');
session_start();

$error = "";
if(array_key_exists('submit', $_POST)){
  if(!$_POST['firstName']){
    $error .= "Need to type in your First Name<br>";
  }
  if(!$_POST['lastName']){
    $error .= "Need to type in your Last Name<br>";
  }
  if(!($_POST['email'] AND $_POST['confirmEmail'])){
    $error .= "Email Field is required<br>";
  }
  if(!($_POST['password'] AND $_POST['confirmPassword'])){
    $error .= "Password Field is required<br>";
  }
  if(!$_POST['phNumber']){
    $error .= "Phone Number Field is required<br>";
  }
  if(!$_POST["position"]){
    $error .= "Please select your position<br>";
  }
  if($error != ""){
    $error = "<p>There were errors in your form: </p>".$error;
  }else{
    $query = "SELECT * FROM `user` WHERE Email = '".mysqli_real_escape_string($link, $_POST['email'])."'";
    $result = mysqli_query($link, $query);
    if(mysqli_num_rows($result) > 0){
        $error = "<p>This Email has been registered. Please try to log in<p>";
    }else{
      if($_POST['email'] != $_POST['confirmEmail']){
        $error = "Email and Confirm Email must be same";
      }
      if($_POST['password'] != $_POST['confirmPassword']){
        $error = "Password and Confirm Password must be same";
      }else{

        $F_Name = $_POST['firstName'];
        $L_Name = $_POST['lastName'];
        $Email = $_POST['email'];
        $mobile = $_POST['phNumber'];
        $password = $_POST['password'];
        $position = $_POST['position'];
        $affiliation = $_POST['affiliation'];
     
        $query = "INSERT INTO user (Email,Password,School,Affiliation,Role,Intake,First_Name,Last_Name,Phone,AccessLevel,Register_Date) VALUES('".$Email."', '".$password."', 'NULL', '".$affiliation."', '".$position."', 'NULL', '".$F_Name."', '".$L_Name."', '".$mobile."','15',CURRENT_TIMESTAMP)";
          
        if(!mysqli_query($link, $query)){
          $error = "<p>Could not sign you up. Please try again later.</p>";
        }else{
            
          
            setcookie("loginAuthorised", "valid", time()+7200, "/");

            setcookie("accessLevel", 15, time()+7200, "/");

            setcookie("Email", $Email, time()+7200, "/");

            header("Location: index.php");
            
            
            
            
        }

      }
    }
  }
}
?>
  <body>
  <?php
		include("navigation.php");

	?>
  <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">OPE</h1>

            </div>
          <div id="error"><?php 
          if($error != ""){
            echo '<div class="alert alert-danger" role="alert">'.$error .'</div>';
          }
          ?></div>
        <form method='post'> 
      <div class="form-group row">
          
        <label for="firstName" class="col-sm-2 col-form-label">First Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="firstName" placeholder="Your First Name">
        </div>
      </div>

      <div class="form-group row">
          
        <label for="lastName" class="col-sm-2 col-form-label">Last Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="lastName" placeholder="Your Last Name">
        </div>
      </div>

      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" name="email" placeholder="Enter Your Email">
        </div>
      </div>

      <div class="form-group row">
      <label for="confirmEmail" class="col-sm-2 col-form-label">Email Confirmation</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" name="confirmEmail" placeholder="Confirm your Email">
        </div>
      </div>
     
      <div class="form-group row">
      <label for="password" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" name="password" placeholder="Enter Your Password">
        </div>
      </div>
      
      <div class="form-group row">
      <label for="confirmedpassword" class="col-sm-2 col-form-label">Confirm Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" name="confirmPassword" placeholder="Enter Your Password Again">
        </div>
      </div>

      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Phone Number</label>
        <div class="col-sm-10">
          <input type="number" class="form-control" name="phNumber" placeholder="Enter Your Phone Number">
        </div>
      </div>

      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Your Position</label>
      <div class="form-group col-sm-10">
            <input type="text" class="form-control" name="position" placeholder="Your Position">
          </div>
      </div>
      
      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Affiliation</label>
      <div class="form-group col-sm-10">
            <input type="text" class="form-control" name="affiliation" placeholder="Your Affiliation">
          </div>
      </div>





      <div class="form-group form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1" name="stayLoggedIn">Stay logged in</label>
                </div>
    <button type="submit" class="btn btn-primary" name="submit">Register</button>
    <a href="index.php"><button type="submit" class="btn btn-danger" name="cancel">Cancel</button></a>
    </form>
    </div>
    </div>

   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>