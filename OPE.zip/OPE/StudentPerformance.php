<?php
    include("header.php");
    include("navigation.php");
    include("connection.php");
?>
 <?php
$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
if(!$loginAuthorised){
 header("Location: index.php");   
}
?>  
<style>
#myInput {

  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 12px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}  
    
    </style>

<style>
#myInput1 {

  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 12px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}  
    
    </style>
<script src="dist/js/tabulator.min.js"></script>
<script src="dist/js/tabulator.js"></script>
<script src="vendor/excel/xlsx.full.min.js"></script>
<script src="custom1/js/jquery-2.1.1.min.js"></script>

<script>

    $(function() {
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable > tbody > tr").filter(function() {      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>


<script>

    $(function() {
  $("#myInput1").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable1 > tbody > tr").filter(function() {      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>
    
<div class="container-fluid">
    
          <h1 class="h3 mb-2 text-gray-800">  </h1>
          <p class="mb-4"> </p>
<div class="card shadow mb-4">
           
            <div class="card-header py-3">
         
              <h6 class="m-0 font-weight-bold text-primary">Individual Presentations List</h6>
              <input type="text" id="myInput"  placeholder="Search " title="Type in a name">
            </div>
            
            <div class="card-body">
              <div class="table-responsive" id="#example-table-download" >
                <table class="table table-bordered"  width="100%" cellspacing="0"  id ="myTable" >
                  <thead>
                    <tr>
                      <th>Presentation Name</th>
                      <th>Module Name</th>
                      <th>Detail</th>
                      <th>Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                       
                     
                        <?php  
                      
             
                      $sql = "Select Name,Module_Name,Detail,Grade from presentation where Presenter_Email = '$profileEmail' and Group_Name = 'Null'";
                     
            $individual_prese_score = mysqli_query($link,$sql);
                    
            while ($row=mysqli_fetch_assoc($individual_prese_score))
            {
                    $PresentationName = $row['Name'];
		    $Module_Name = $row['Module_Name'];
		    $Detail = $row['Detail'];
		    $Grade = $row['Grade']; 
					
					?> 
                    <tr>
                      <td><?php echo $PresentationName ?></td>
                      <td><?php echo $Module_Name ?></td>
                      <td><?php echo $Detail ?></td>
                      <td><?php echo $Grade ?></td>
                    </tr>                
                    <?php        
           } ?>
                  </tbody>
                </table>
                                    

              </div>
            </div>


       <div>
       <a href="#" id="test" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onClick="javascript:fnExcelReport();">Download Report</a>

    </div>
    
    <!-- Grp-->
    
    
            <div class="card-header py-3">
         
              <h6 class="m-0 font-weight-bold text-primary">Group Presentations List</h6>
              <input type="text" id="myInput1"  placeholder="Search " title="Type in a name">
            </div>
            
            <div class="card-body">
              <div class="table-responsive" id="#example-table-download" >
                <table class="table table-bordered"  width="100%" cellspacing="0"  id ="myTable1" >
                  <thead>
                    <tr>
                      <th>Presentation Name</th>
                        <th>Group Name</th>
                      <th>Module Name</th>
                      <th>Detail</th>
                      <th>Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                       
                     
                        <?php  
                      
             
//                      $sql = "Select Name,Module_Name,Detail,Grade from presentation where Presenter_Email = '$profileEmail'";
                     $sql = " Select Name,Group_name,Module_Name,Detail,Grade from presentation
where Presenter_Email in(select S_Email from group_presentation where S_Email ='$profileEmail') AND Group_Name!= 'Null'";
                     
            $individual_prese_score = mysqli_query($link,$sql);
                    
            while ($row=mysqli_fetch_assoc($individual_prese_score))
            {
                    $PresentationName = $row['Name'];
                  $Group_Name = $row['Group_name'];
		    $Module_Name = $row['Module_Name'];
		    $Detail = $row['Detail'];
		    $Grade = $row['Grade']; 
					
					?> 
                    <tr>
                      <td><?php echo $PresentationName ?></td>
                        <td><?php echo $Group_Name ?></td>
                      <td><?php echo $Module_Name ?></td>
                      <td><?php echo $Detail ?></td>
                      <td><?php echo $Grade ?></td>
                    </tr>                
                    <?php        
           } ?>
                  </tbody>
                </table>
                                    

              </div>
            </div>


       <div>
       <a href="#" id="test1" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onClick="javascript:fnExcelReport1();">Download Report</a>
    
    </div>
    
    
    
 <script>
function fnExcelReport() {
 var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
 tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
 tab_text = tab_text + '<x:Name>Individual Report</x:Name>';
 tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
 tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';
 tab_text = tab_text + "<table border='1px'>";
 
//get table HTML code
 tab_text = tab_text + $('#myTable').html();
 tab_text = tab_text + '</table></body></html>';
    
//    var data_type = 'data:application/vnd.ms-excel';
    var data_type = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
 
 var ua = window.navigator.userAgent;
 var msie = ua.indexOf("MSIE ");
 //For IE
 if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      if (window.navigator.msSaveBlob) {
      var blob = new Blob([tab_text], {type: "application/csv;charset=utf-8;"});
      navigator.msSaveBlob(blob, 'Individual Report.xls');
      }
 } 
//for Chrome and Firefox 
else {
 $('#test').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
 $('#test').attr('download', 'Individual Report.xls');
}
}
</script>
    
   
    
    
    <script>
function fnExcelReport1() {
 var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
 tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
 tab_text = tab_text + '<x:Name>Individual Report</x:Name>';
 tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
 tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';
 tab_text = tab_text + "<table border='1px'>";
 
//get table HTML code
 tab_text = tab_text + $('#myTable1').html();
 tab_text = tab_text + '</table></body></html>';
    
//    var data_type = 'data:application/vnd.ms-excel';
    var data_type = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
 
 var ua = window.navigator.userAgent;
 var msie = ua.indexOf("MSIE ");
 //For IE
 if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      if (window.navigator.msSaveBlob) {
      var blob = new Blob([tab_text], {type: "application/csv;charset=utf-8;"});
      navigator.msSaveBlob(blob, 'Group Report.xls');
      }
 } 
//for Chrome and Firefox 
else {
 $('#test1').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
 $('#test1').attr('download', 'Group Report.xls');
}
}
</script>
    
    
    
    
    
    
<?php
    include('footer.php');
?>