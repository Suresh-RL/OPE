<?php

if(isset($_GET['status'])){
    $status = $_GET['status'];
	if (isset($status) AND ($status == "logout")) {
        
        //If logout, remove all the cookies
		setcookie("loginAuthorised", "", time()-7200,"/");	
        setcookie("accessLevel", 0, time()-7200, "/");	
        setcookie("Email", "", time()-7200, "/");
        header("Location: index.php");
	
	} 
}

if(isset($_GET['status'])){
    $status = $_GET['status'];
	if (isset($status) AND ($status == "login")) {
        
    echo '<script>alert("Please log in to register the event!");</script>';
	//header("Location: index.php");
	} 
}



if(isset($_COOKIE["loginAuthorised"])){
$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");

}
include("header.php");

  ?>

  <body>

    <!-- Navigation -->
    
    <?php
		include("navigation.php");

	?>



    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->
          <div class="carousel-item active" style="background-image: url('Images/presentation1.jpg')">
            <div class="carousel-caption d-none d-md-block">
              
              <h4><i>"You can speak well if your tongue can deliver the message of your heart."</i></h4>
            </div>
          </div>
          <!-- Slide Two - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('Images/presentation2.jpg')">
            <div class="carousel-caption d-none d-md-block">
              
              <h4><i>"Practice makes perfect."</i></h4>
            </div>
          </div>
          <!-- Slide Three - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('Images/presentation3.jpg')">
            <div class="carousel-caption d-none d-md-block">
             
              <h4><i>"Confidence is the most attractive quality a person can have."</i></h4>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </header>

  
  
  
   <?php

    include('connection.php');
    if($link){
        
        $UpcomingSQL ="SELECT * FROM presentation WHERE Status = 'Upcoming'";
        
        $UpcomingQuery = mysqli_query($link, $UpcomingSQL);
        
        $indx = 0;
        
        while($row = mysqli_fetch_assoc($UpcomingQuery)){
            
            $UList[$indx]['ID'] = $row['Presentation_ID'];
            $UList[$indx]['Name'] = $row['Name'];
            $UList[$indx]['Detail'] = $row['Detail'];  
            $indx++;
            if($indx == 3){
             break;   
            }
        }
    }
        ?>
        
        
        
    <div class="container">
      
  
      
      
    <?php
if($indx>0 AND $indx==3){
    
    echo '<h1 class="my-4">Upcoming Presentation</h1>
      <div class="row">';
    
     for($indx = 0;$indx<3;$indx++){
         
      echo '<!-- Marketing Icons Section -->
        
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header">'.$UList[$indx]['Name'].'</h4>
            <div class="card-body">
              <p class="card-text">'.$UList[$indx]['Detail'].'</p>
            </div>
            <div class="card-footer">
              <a href="PresentationDetail.php?id='.$UList[$indx]['ID'].'" class="btn btn-primary">View Details</a>
            </div>
          </div>
     </div>';
                  
     }
}
        ?>
                </div>
                </div>
        <?php
      include('footer.php');
        
  ?>