<?php
  include("header.php");
  include("navigation.php");
  include('connection.php');
  

 $loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");


//If login is not authorised, force user to quit from this page
if(!$loginAuthorised){
    
 header("Location: index.php?status=login");   
}else{
 $user_email = $_COOKIE["Email"];   
}

  if(isset($_GET['id'])){
    $presentation_id = $_GET['id'];
    $query = "SELECT * FROM presentation WHERE Presentation_ID = '".$presentation_id."'";
    $result = mysqli_query($link, $query);
    while($row = mysqli_fetch_assoc($result)){
   
      $title = $row['Name'];
      $detail = $row['Detail'];
      $status = $row['Status'];
      $startdate = $row['start'];
      $enddate = $row['end'];
      $presenters = $row['Presenter_Email'];
      $venue = $row['Location'];
      $grade = $row['Grade'];
    }
      
    $checkQuery = "SELECT * FROM attendee WHERE Presentation_ID = '".$presentation_id."' AND Email = '".$user_email."'";
      $checkResult = mysqli_query($link, $checkQuery);
      while($row = mysqli_fetch_assoc($checkResult)){
   
      $checkEmail = $row['Email'];
          
      }
      if(!isset($checkEmail)){
       $register = "You have not registered the event";   
          
      }
      else{
       $register = "You have registered the event";   
      }
      
      
  }


  if(array_key_exists('accept', $_POST)){
      echo $presentation_id;
      echo $user_email;
    $insert_query = "INSERT INTO attendee(Presentation_ID, Email, Metric_ID, Feedback, Grade, Status) VALUES ('".$presentation_id."', '".$user_email."', NULL, 'NULL','NULL','Attend')";
      if(!mysqli_query($link, $insert_query)){
          //echo $insert_query;
          echo '<script>alert("Already have a registration record for the event");</script>';
          
          echo $insert_query;
          echo "<br>";
          echo("Error is ".mysqli_error($link));
      }else{
          //echo "Data has been inserted";
          if(array_key_exists('register', $_GET)){
          echo '<script>alert("Registered the event!");</script>';
              //header("Location: calendar.php");   
              header("Refresh:0");
          }
      }
  }
  if(array_key_exists('cancel', $_POST)){
    $delete_query = "DELETE FROM attendee WHERE Presentation_ID = '".$presentation_id."' AND Email = '".$user_email."'";
    mysqli_query($link, $delete_query);
      if(!mysqli_query($link, $delete_query)){
          //echo $insert_query;
          echo '<script>alert("No record");</script>';
      }else{
          //echo "Data has been inserted";
          if(array_key_exists('register', $_GET)){
          echo '<script>alert("Record deleted");</script>';
              //header("Location: calendar.php");   
              header("Refresh:0");
          
          }
      }
  }

?>
  <body>
<!--
    <div class="container">
    <div class="row"></div>
    <div class="col-sm">
-->
    <form method="post" action="RegisterToAttend.php?id=<?php echo $presentation_id; ?>&register=ok"> 
    <h2><?php if(isset($title)){echo $title;} ?></h2>
    <p>
     <?php echo $detail; ?>

    </p>
    <h3>Presentation Status</h3>
    <table class="table">
           
            <tbody>
              <tr>
                <th scope="row">Presentation Status</th>
                <td><?php echo $status; ?></td>
              </tr>
              <tr>
                    <th scope="row">Presentation Start Time</th>
                    <td><?php echo $startdate; ?></td>
              </tr>
              <tr>
                <th scope="row">Location</th>
                <td><?php echo $venue; ?></td>
          </tr>
              <tr>
                    <th scope="row">Presenters</th>
                    <td><?php echo $presenters; ?></td>
                </tr>
                <tr>
                    <th scope="row">Registration status</th>
                    <td><?php echo $register; ?></td>
                </tr>
            </tbody>
          </table>
          <form method="post">
          <button type="submit" class="btn btn-success" name="accept">Accept</button>
          <button type="cancel" class="btn btn-success" name="cancel">Cancel the registration</button>
              <td><a href="PresentationDetail.php?id=<?php if(isset($presentation_id)){echo $presentation_id;} ?>"><button type="button" class="btn btn-danger">Detail</button></a></td>
          <td><a href="calendar.php"><button type="button" class="btn btn-danger">Back to Calendar</button></a></td>
              
       </form>
    </form>
    </div>
    </div>
    </div>
    
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>