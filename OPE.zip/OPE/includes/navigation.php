
<?php 
if(isset($_COOKIE["Email"])){
  $profileEmail = $_COOKIE["Email"];
}

?>
 <!-- Navigation -->
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
        <div class="container">
            
          <a class="navbar-brand" href="index.php">ONLINE PRESENTATION EVALUATOR</a>
          <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          
          <div  id="navbarResponsive">
              
            <ul class="navbar-nav ml-auto">
              
            
              <li class="nav-item">
                <a class="nav-link" href="calendar.php">Calender</a>
              
              
              <?php
                if(isset($profileEmail)){
              echo '<li class="nav-item">
                  <a class="nav-link" href="Menu.php">'.$profileEmail.'</a>
              </li>';
                  
                }
               ?>
              <li class="nav-item" id="loginForm">
              
              <?php
                if(isset($profileEmail)){
                
                echo '
                 <a href="Menu.php"'; echo $profileEmail; echo '"><img src="Images/login.png" width="50" height="50"></a>
                </li>';
                
                }
                else{
                    
                echo'<a href="login.php"><button class="btn btn-success my-2 my-sm-0" type="submit">Log In</button></a>
                  <a href="registerPage.php"><button class="btn btn-danger my-2 my-sm-0" type="submit">Sign Up</button></a>
                </li>';
                
                }
?>
                
                
                
                 
                
                
            </ul>
          </div>
        </div>
      </nav> <!--- Nav -->


 