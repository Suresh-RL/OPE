<?php

//load.php

$connect = new PDO('mysql:host=localhost;dbname=ope_db', 'ope@localhost', 'Po827128*');

$data = array();

$query = "SELECT * FROM presentation";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

foreach($result as $row)
{
 $data[] = array(
  'id'   => $row["Presentation_ID"],  
  'title'   => $row["Name"],
  'start'   => $row["start"],
  'end'   => $row["end"]
 );
}

echo json_encode($data);

?>