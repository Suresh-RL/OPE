p<?php 


 

if(array_key_exists('submit', $_POST)){
    
    if(isset($_POST["forget_email"])){
        $femail = $_POST["forget_email"];
         include("connection.php");
        
        $resetSQL = "SELECT Password FROM user WHERE Email = '".$femail."'";
        $resetQuery = mysqli_query($link, $resetSQL);
     
            $pas = "";
        if($row = mysqli_fetch_assoc($resetQuery)){
            
            $pas = $row['Password'];
        }
             $subject = "Password Query";
            $to = $femail;
      $headers  = 'From: onlinepresentationevaluator@gmail.com' . "\r\n" .
            'MIME-Version: 1.0' . "\r\n" .
            'Content-type: text/html; charset=utf-8';
            $message = "Hi User,<br><br>You recently requested a password query. <br><br>Password: ".$pas."<br><br>This is an auto-generated message, please do not reply.";  
        
        
if(mail($to, $subject, $message, $headers)){
    echo '<script>alert("The password is sent to the email!");</script>';
    //header("Refresh:0");
}
        else{
            //header("email_error.php");
            echo "Error in sending email";
        }
        
            
       
        
        
    }
        
    
}
    
    

?>
<?php
    include('header.php');
?>
  <body>

    <!-- Navigation -->
    <?php
		include('navigation.php');
	?>
    <!-- Page Content -->
    <div class="container">
    
    <div id="resetForm">
    <form method="post">
    <div class="form-group">
        <label for="rest_email">Email address</label>
        <input type="email" class="form-control" name="forget_email" id="reset_email"  placeholder="Enter email">
  </div>
  <button type="submit" class="btn btn-danger" name="submit">Reset Password</button>
    </form>
    </div>


   
       <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
 
  </body>

</html>
