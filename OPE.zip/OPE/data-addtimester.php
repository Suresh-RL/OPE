<?php include "connection.php";?>
<?php
// header('Content-Type: application/json');
$tName = $_POST['tName'];
$tYear = $_POST['tYear'];


 $sql="INSERT INTO `trimester`( `Year`, `Name`,`isCurrent`) VALUES ('$tYear','$tName','Yes')";
 $chkexistquery = mysqli_query($link,"SELECT * FROM `trimester` WHERE `Year`='$tYear' AND `Name` ='$tName'");

if(mysqli_num_rows($chkexistquery) > 0) {

        echo "The Trimester already exists.";
    }
    elseif(!mysqli_query($link,$sql)) {
       echo 'Error - Could not insert';

    }
    else {
     echo "Trimester is added";
    }
 
    //Close connection
    mysqli_close($link);
 // echo json_encode($message);

?>