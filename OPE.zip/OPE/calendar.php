<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8' />
<link href='fullCalendar/fullcalendar.min.css' rel='stylesheet' />
<link href='fullCalendar/fullcalendar.print.min.css' rel='stylesheet' media='print' />
<script src='lib/moment.min.js'></script>
<script src='lib/jquery.min.js'></script>
<script src='fullCalendar/fullcalendar.min.js'></script>

<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">


<script>

  $(document).ready(function() {

    var calendar = $('#calendar').fullCalendar({
    editable:true,
    header:{
     left:'prev,next today',
     center:'title',
     right:'month,agendaWeek,agendaDay'
    },
    events: 'loadCalendar.php',
    selectable:true,
    selectHelper:true,
       
       eventClick:function(event)
    {
     
      var id = event.id;
      window.location.href="PresentationDetai_Reg.php?id="+id;//GET method
      
    },
    



   });
  });

</script>
<style>

  body {
    margin: 40px 10px;
    padding: 0;
    font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
    font-size: 14px;
  }

  #calendar {
    max-width: 900px;
    margin: 0 auto;
  }

</style>
</head>
<body>
  <?php
		include("navigation.php");

	?>
	<br />
  <h2 align="center"><a href="#">Presentations on Calendar</a></h2>
  <br />
  <div class="container">
   <div id="calendar"></div>
  </div>

</body>
</html>