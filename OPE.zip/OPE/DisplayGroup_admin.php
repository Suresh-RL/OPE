<?php include "includes/adminheader.php";?>
      <?php include "connection.php";?>  

 <?php

    $title = $_GET['title'];

?>
     
     
          
 <?php
$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
if(!$loginAuthorised){
 header("Location: index.php");   
}
?>  
<style>
#myInput {

  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 12px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}  
    
    </style>
<script src="dist/js/tabulator.min.js"></script>
<script src="dist/js/tabulator.js"></script>
<script src="vendor/excel/xlsx.full.min.js"></script>
<script src="custom1/js/jquery-2.1.1.min.js"></script>

<script>

    $(function() {
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable > tbody > tr").filter(function() {      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>   
     
      
        <!-- Begin Page Content -->
       <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Group Information</h1>
          
            <div class="card shadow mb-4">
            <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Group Information for the presentation - <?php echo $title ?></h6>
                </div>
              
<!--<div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="dataTable_length"><label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="dataTable_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable"></label></div></div></div>-->
               
                          
               <div class="table-responsive">
                <table class="table table-bordered"  ;id="dataTable" width="2000%" cellspacing="0" id ="myTable">
                  <thead>
                    <tr>
                      <th>Student Name</th>
                      <th>Email</th>
                    </tr>
                  </thead>
          <?php  
                    
                    if(isset($_GET['title'])){
                        $presentId = $_GET['title'];
                        $sql = "SELECT CONCAT (First_Name,' ',Last_Name)as 'stud_name', Email from user
                          WHERE Email in (select S_Email from group_presentation where  S_Email = Email and Presentation_ID = '".$presentId."')";
                        
                        
                    }
            
            $individual_prese_score = mysqli_query($link,$sql);
                    if(!$individual_prese_score){
                        echo $sql;
                    }
                    
            while ($row=mysqli_fetch_assoc($individual_prese_score))
            {
                    $stud_name = $row['stud_name'];
                    $Email = $row['Email'];
				
					
					?> 
                  <tbody>
                    <tr>
                      <td><?php echo $stud_name ?></td>
                      <td><?php echo $Email ?></td>
                    </tr>

                    <?php        
           } ?>
           
                     </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>

   
   
   
<!-- Group Presentation Table-->
<!--
 
 <div class="card shadow mb-4">
            <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Group Presentations list</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
              
<div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="dataTable_length"><label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="dataTable_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable"></label></div></div></div>
               
                          
               <div class="table-responsive">
                <table class="table table-bordered"  ;id="dataTable" width="2000%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Presentation ID</th>
                      <th>Group Name</th>
                      <th>Presentation Name</th>
                      <th>Module</th>
                      <th>Detail</th>
                      <th>Grade</th>
                    </tr>
  
           
                     </tbody>
                </table>

          </div>

        </div>
 
-->
  
   
               </div>
        <!-- /.container-fluid -->
   
   
   <!-- End of Main Content -->
         <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
<!--            <span>Copyright &copy; Your Website 2019</span>-->
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

   </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>