<?php

 $user_query = "SELECT First_Name, Last_Name, School, Intake, Phone, Affiliation, Role, Register_Date FROM user WHERE Email = '".$PEmail."'";
     $account_query = mysqli_query($link, $user_query);
    if($account_query){
        echo "Retrieved user information ";
        
        while($row = mysqli_fetch_assoc($account_query)){
            $FN = $row['First_Name'];
            $LN = $row['Last_Name'];    
            $SC = $row['School'];
            $IN = $row['Intake'];    
            $PH = $row['Phone'];    
            $AF = $row['Affiliation'];    
            $RO = $row['Role'];    
            $RE = $row['Register_Date'];    
 
        }
    }
    else{
     echo "Error!!";   
    }





?>