<?php include "includes/adminheader.php";?>
<?php include "connection.php";?>  
        <!-- Begin Page Content -->
        
        
 <?php
$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
if(!$loginAuthorised){
 header("Location: index.php");   
}
?>  
<style>
#myInput {

  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 12px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}  
    
    </style>
<script src="dist/js/tabulator.min.js"></script>
<script src="dist/js/tabulator.js"></script>
<script src="vendor/excel/xlsx.full.min.js"></script>
<script src="custom1/js/jquery-2.1.1.min.js"></script>

<script>

    $(function() {
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable > tbody > tr").filter(function() {      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>
       
       
        <div class="container-fluid">

          <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Individual Presentations</h1>
          <p class="mb-4">Individual Presentation details of modules</p>

          <!-- Individual Pesentation Details -->
 <div class="card shadow mb-4">
           
            <div class="card-header py-3">
         
              <h6 class="m-0 font-weight-bold text-primary">Individual Presentations List</h6>
               <input type="text" id="myInput"  placeholder="Search " title="Type in a name">
            </div>
            </div>
            
            <div class="card-body">
              <div class="table-responsive" id="#example-table-download" >
                <table class="table table-bordered"  width="100%" cellspacing="0"  id ="myTable" >
                  <thead>
                    <tr>
                      <th>Presentation ID</th>
                      <th>Student Name</th>
                      <th>Module</th>
                      <th>Detail</th>
                      <th>Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php  $sql = "SELECT a.Presentation_ID,CONCAT (b.First_Name,' ',b.Last_Name)as 'stud_name',a.Module_Name,a.Detail,a.Grade from presentation a, user b
	            where a.Presenter_Email = b.email and a.Status = 'Completed'"; 
            
            $individual_prese_score = mysqli_query($link,$sql);
                    
            while ($row=mysqli_fetch_assoc($individual_prese_score))
            {
                    $Presentation_ID = $row['Presentation_ID'];
                    $stud_name = $row['stud_name'];
					$Module_Name = $row['Module_Name'];
					$Detail = $row['Detail'];
					$Grade = $row['Grade'];
					
					?> 
                    <tr>
                      <td><?php echo $Presentation_ID ?></td>
                      <td><?php echo $stud_name ?></td>
                      <td><?php echo $Module_Name ?></td>
                      <td><?php echo $Detail ?></td>
                      <td><?php echo $Grade ?></td>
                    </tr>                
                    <?php        
           } ?>
                  </tbody>
                </table>
              </div>
            
            
            
<!--
           
          
          



<!--        <input id="clickMe" type="button"  class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" value="Download Report" onclick="function();" />-->
<!--<div > <button   class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onClick="javascript:fnExcelReport();"  >Download Report</button> </div><div > <button   class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onClick="javascript:fnExcelReport();"  >Download Report</button> </div>-->
       
       <a href="#" id="test" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onClick="javascript:fnExcelReport();">Download Report</a>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
<!--
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
-->
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>



<!--

<script type="text/javascript">
    TableLoader.register("download", function(){

       $("#download-xlsx").click(function(){
           example_table_download.download("xlsx", "data.xlsx");
       });

       var example_table_download = new Tabulator("#example-table-download", {
           height:"311px",
           data:tabledata,
           columns:[
           {title:"Presentation ID", field:"Presentation ID", width:200},
           {title:"Student Name", field:"Student Name", width:100},
           {title:"Presentation Name", field:"Presentation Name"},
           {title:"Module", field:"Module", width:80},
           {title:"Detail", field:"Detail"},
           {title:"Grade", field:"Grade", align:"center"},
           ],
       });
   })
</script>



-->

<!--
<script type="text/javascript">
  var table = new Tabulator("#example-table", {
    height:"311px",
    columns:[
           {title:"Presentation ID", field:"Presentation ID", width:200},
           {title:"Student Name", field:"Student Name", width:100},
           {title:"Presentation Name", field:"Presentation Name"},
           {title:"Module", field:"Module", width:80},
           {title:"Detail", field:"Detail"},
           {title:"Grade", field:"Grade", align:"center"},
           ],
       });
    
$("#download-xlsx").click(function(){
    table.download("xlsx", "data.xlsx", {sheetName:"My Data"});
});
</script>
-->
<script>
function fnExcelReport() {
 var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
 tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
 tab_text = tab_text + '<x:Name>Individual Report</x:Name>';
 tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
 tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';
 tab_text = tab_text + "<table border='1px'>";
 
//get table HTML code
 tab_text = tab_text + $('#myTable').html();
 tab_text = tab_text + '</table></body></html>';
    
//    var data_type = 'data:application/vnd.ms-excel';
    var data_type = 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
 
 var ua = window.navigator.userAgent;
 var msie = ua.indexOf("MSIE ");
 //For IE
 if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      if (window.navigator.msSaveBlob) {
      var blob = new Blob([tab_text], {type: "application/csv;charset=utf-8;"});
      navigator.msSaveBlob(blob, 'Individual Report.xls');
      }
 } 
//for Chrome and Firefox 
else {
 $('#test').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
 $('#test').attr('download', 'Individual Report.xls');
}
}
</script>
<!--
  <script>
function myFunction() {
table.download("xlsx", "data.xlsx", {sheetName:"MyData"});
}
</script>
-->
 
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
<!--
  <script src="js/demo/datatables-demo.js"></script>


  <script type="text/javascript" src="vendor/excel/xlsx.full.min.js"></script>
  <script src="src/jquery.table2excel.js"></script>
  <script src="dist/jquery.table2excel.min.js"></script>
-->
  <script type="text/javascript" src="dist/js/tabulator.min.js"></script>
  <script type="text/javascript" src="dist/js/tabulator.js"></script>
   <script type="text/javascript" src="vendor/excel/xlsx.full.min.js"></script>
   <script type="text/javascript" src="http://oss.sheetjs.com/js-xlsx/xlsx.full.min.js"></script>


</body>

</html>
