<?php
  include('connection.php');
  include('header.php');
  include('navigation.php');
  session_start();
 $error = "";
//  $presentation_id = $_SESSION['link']
//  $assessor = $_SESSION['email'];
// $query_assessor = "SELECT * FROM user WHERE Email = {$assessor}";
// $assessor_result = mysqli_query($link, $query_assessor);
// while($row_accessor = mysqli_fetch_assoc($assessor_result)){
//   $assessor_id = $row_accessor['User_id'];
// }
// if(isset($_GET['p_id'])){
//   $_SESSION['link'] = $_GET['p_id'];
// }
?>
<br><br>
 <body>
    <div class="container">
    <div class="row"></div>
    <div class="col-sm">
    
    <div id="error"><?php 
          if($error != ""){
            echo '<div class="alert alert-alert" role="alert">'.$error .'</div>';
          }
          ?></div>
    <?php
            if(isset($_GET['p_id'])){
              $presentation_id = $_GET['p_id'];
              $UEmail = $_COOKIE["Email"];
              // $AccessLevel = $_COOKIE["accessLevel"];

              $query = "SELECT * FROM presentation WHERE Presentation_ID = {$presentation_id}";
              $result = mysqli_query($link, $query);
              while($row = mysqli_fetch_assoc($result)){
                $title = $row['Name'];
                $detail = $row['Detail'];
                $status = $row['Status'];
                $date = $row['start'];
                $presenters = $row['Presenter_Email'];
                // $attendees = $row['Attendees'];
                $grade = $row['Grade'];
              ?>
    <h2><?php echo $title; ?></h2>
    <p>
        <?php echo $detail; ?>

    </p>
    <h3>Presentation Status</h3>
    <table class="table">
           
            <tbody>
              <tr>
                <th scope="row">Presentation Status</th>
                <td><?php echo $status; ?></td>
              </tr>
              <tr>
                    <th scope="row">Presentation Date</th>
                    <td><?php echo $date; ?></td>
              </tr>
              <tr>
                    <th scope="row">Presenters</th>
                    <td><?php echo $presenters; ?></td>
                </tr>
                <!-- <tr>
                        <th scope="row">Atendees</th>
                        <td><?php echo $attendees; ?></td>
                </tr> -->
                <?php
              }
            }
                ?>
            </tbody>
          </table>
        <h3> Feedback</h3>
        <?php
$error = "";
  if(isset($_POST['giveGrade'])){
    // $presentation_id = $_GET['p_id'];
    if(!$_POST['grade']){
        $error .= "Please give the final grade.<br>";   
    }
    if(!$_POST['feedback']){
      $error .= "Please give the feedback.<br>";
    }
    if($error){
        $error = "There are a few error in this form".$error;
    }else{
      $grade = $_POST['grade'];
      $feedback = $_POST['feedback'];
      $query_user = "UPDATE attendee SET Feedback = '".$feedback."', Grade =".$grade.", Status = 'Completed' WHERE Presentation_ID='".$presentation_id."' AND Email = '".$UEmail."'"; 
    
      if(!mysqli_query($link, $query_user)){
        $error = "<p>Could not create. please try again later</p>";
      }else{
        $update_query = "UPDATE presentation SET Status = 'Completed', Grade = '{$grade}' WHERE Presentation_ID = {$presentation_id}";
        mysqli_query($link, $update_query);
          echo '<script>alert("Grade is given!");</script>';
              //header("Location: index.php");   
              //header("Refresh:0");
          
      }
    }
  }
?>
        <form action="" method="post" role="form">
                <div class="form-group row">
                        <img for="feedback" class="col-form-label" src="images/login.png" width="70" height="70">
                        <div class="col-sm-8">
                          <input type="text" id="grade" name="grade" placeholder="Give Grade" class="form-control">
                          <textarea type="text" class="form-control" name="feedback" id="feedback" value="" placeholder="Leave Feedback"></textarea>
                          <button type="submit" class="btn btn-primary" name="giveGrade">Post</button>
                        </div>
                        
                </div>
        </form>
   
    </div>
    </div>
    </div>
    
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>