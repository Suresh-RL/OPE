<?php 
include('header.php'); 

$error = "";

if(array_key_exists('submit', $_POST)){
  include('connection.php');
  if(!$_POST['email']){
    $error .= "Email is required.<br>";
  }
  if(!$_POST['password']){
    $error .= "Password is required.<br>";
  }
  if($error != ""){
    $error = "<p>There were some errors. </p>". $error;
  }else{
    $query = "SELECT * FROM `user` WHERE Email = '".mysqli_real_escape_string($link, $_POST['email'])."'";
    $result = mysqli_query($link, $query);
    $row = mysqli_fetch_array($result);
    if(isset($row)){
      $LoginPassword = $_POST['password'];
      if($LoginPassword == $row['Password']){
        
          $accessLevel = $row['AccessLevel'];   
          $email = $_POST['email'];
          setcookie("loginAuthorised", "valid", time()+7200, "/");

            setcookie("accessLevel", $accessLevel, time()+7200, "/");

            setcookie("Email", $email, time()+7200, "/");
          
          header("Location: index.php");
          
          
          
        if(array_key_exists('stayLoggedIn', $_POST)){
          set_cookie("email",$row['Email'],time()+60*60*24*365);
      
        }
        
      }else{
        $error = "password and email is not matched";
      }

    }else{
      $error = "That email/password combincation could not be found";
    }
  }
}
?>
  <body class="gray-bg">
    <?php
		include("navigation.php");

	?>
    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">OPE</h1>

            </div>
           
          <div id="error"><?php 
            if($error != ""){
              echo '<div class="alert alert-danger" role="alert">'.$error.'</div>';
            }
          ?></div>
            <form class="m-t" role="form" method="post">
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Enter Your Email" name="email" required="">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="password" required="">
                </div>
                <div class="form-group form-check">
                  <input type="checkbox" class="form-check-input" id="exampleCheck1">
                  <label class="form-check-label" for="exampleCheck1" name="stayLoggedIn">Stay logged in</label>
                </div>
                <button type="submit" class="btn btn-primary block full-width m-b" name="submit">Login</button><br>

                <a href="forgetPassword.php"><small>Forgot password?</small></a>
                <p class="text-muted text-center"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="registerPage.php">Create an account</a>



   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>