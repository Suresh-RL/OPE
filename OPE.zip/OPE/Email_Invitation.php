<?php
  include("header_2.php");
  include("connection.php");
  

if(isset($_GET["id"]))
{

    $Pid = $_GET["id"];

    $Plink = "PresentationDetail.php?id='.$Pid.'";
}else
{
     header("Location: index.php");      
}


  $error = "";
  if(array_key_exists('submit', $_POST)){
    
    if(!$_POST['m1']){
      $error .= "Please give your Message<br>";
    }
    if(!$_POST['a1']){
      $error .= "Please type attendees to invite<br>";
    }
    if(!$_POST['p1']){
        $error .= "Please type the Presenter Name<br>";
    }
    if($error!=""){
      $error = "<p> There are a few errors in this form:<p>".$error;
    }else{
        
      
      $Pmessage = $_POST['m1'];
      $to = $_POST['a1'];
      $school = $_POST['s1'];
      $Presenter_Name = $_POST['p1'];
      $PEmail = ($_COOKIE["Email"]);
        
        
    //$user_query = "SELECT First_Name, Last_Name, School, Intake, Phone, Affiliation, Role, Register_Date FROM user WHERE Email = '".$PEmail."'";
    if($link){
        
        $getNameSQL ="SELECT Name FROM presentation WHERE Presentation_ID = '".$Pid."'";
        
        $NameQuery = mysqli_query($link, $getNameSQL);
        
        $indx = 0;
        
        if($row = mysqli_fetch_assoc($NameQuery)){
            
            $Pname = $row['Name'];
        }
    }
        $subject = "Presentation Invitation";
      $headers  = 'From: onlinepresentationevaluator@gmail.com' . "\r\n" .
            'MIME-Version: 1.0' . "\r\n" .
            'Content-type: text/html; charset=utf-8';
        
        $message = "Hi,<br>We would like to invite you to attend the presentation, the detail is provided as following:<br><br>Presentation title: ".$Pname."<br>What about it: ".$Pmessage."<br>Presenter name: ".$Presenter_Name."<br>Email: ".$PEmail."<br>URL: 134.115.149.136/ope/PresentationDetail.php?id=".$Pid."<br><br>Regards,<br>".$school."<br>This is an auto-generated message, please do not reply.";  
        
        
if(mail($to, $subject, $message, $headers)){
    echo '<script>alert("Invitation email is sent!");</script>';
    //header("Location: advertising.php?send=ok");
    header("Refresh:0");
}
        else{
            header("email_error.php");
        }
        
         
    }//end else
  }
?>
 
 
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Email Invitation</title>
    <style>
        /* body{
          background-image: url("Images/giveFeedback.jpg")
        }*/
    </style>
    
    
    <style>
#myDIV {
  width: 100%;
  padding: 50px 0;
  text-align: center;
  background-color: lightblue;
  margin-top: 20px;
  visibility: hidden;
}
</style>
    
    
    
  </head>
  <body>
   <?php
		include("navigation.php");

	?>
   
    <div class="container mainBody">
    <div class="col-10">
    <h1>Email Invitation</h1>
    <form method="post"> 
    <div id="error"><?php 
          if($error != ""){
            echo '<div class="alert alert-primary" role="alert">'.$error .'</div>';
          }
          ?></div>

      <div class="form-group row">
          
        <label for="title" class="col-sm-2 col-form-label">Message</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="M1" name="m1" placeholder="Message">
        </div>
      </div>

       <div class="form-group row">
          
        <label for="school" class="col-sm-2 col-form-label">School</label>

    <div class="form-group col-sm-10">
    <select class="form-control" id="s1" name="s1">
      <option>School of Arts</option>
      <option>School of Business & Governance</option>
      <option>School of Education</option>
      <option>School of Engineering & Interformation Technology</option>
      <option>School of Health Professions</option>
      <option>School of Law</option>
      <option>School of Psychology & Exercise Science</option>
      <option>School of Veterinary & Life Science</option>
      <option>School of Public Policy & International Affairs</option>

    </select>
  </div>
</div>
    <div class="form-group row">
            <label for="presenters" class="col-sm-2 col-form-label">Presenter Name</label>
            <div class="col-sm-10">
              <input type="text" multiple class="form-control" id="p1" name="p1" placeholder="Presenters' Name">
            </div>
          </div>
      
      <div class="form-group row">
          <label for="attendees" class="col-sm-2 col-form-label">Receiver Email</label>
          <div class="col-sm-10">
            <input type="email" multiple class="form-control" id="a1" name="a1" placeholder="Attendees' Emails">
          </div>
        </div>
               
               
                <br><button type="submit" class="btn btn-primary" name="submit">Send Email</button>
       
                <td><a href="advertising.php"><button type="button" class="btn btn-primary">Return</button></a></td>

    </form>
    </div>
    </div>
    
    

   

      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <script type="text/javascript">
  
    </script>
  </body>
</html>