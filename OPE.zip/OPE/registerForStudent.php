<?php 
//include('header.php'); 
include('connection.php');


$error = "";
if(array_key_exists('submit', $_POST)){
  if(!$_POST['firstName']){
    $error .= "Need to type in your First Name<br>";
  }
  if(!$_POST['lastName']){
    $error .= "Need to type in your Last Name<br>";
  }
  if(!$_POST['email']){
    $error .= "Email Field is required<br>";
  }
  if(!$_POST['password']){
    $error .= "Password Field is required<br>";
  }
  if(!$_POST['phNumber']){
    $error .= "Phone Number Field is required<br>";
  }
  
  if($error != ""){
    $error = "<p>There were errors in your form: </p>".$error;
  }else{
    $query = "SELECT * FROM `user` WHERE Email = '".mysqli_real_escape_string($link, $_POST['email'])."'";
    $result = mysqli_query($link, $query);
    if(mysqli_num_rows($result) > 0){
        $error = "<p>This Email has been registered. Please try to log in<p>";
    }else{

        $F_Name = $_POST['firstName'];
        $L_Name = $_POST['lastName'];
        $Email = $_POST['email'];
        $mobile = $_POST['phNumber'];
        $password = $_POST['password'];
        $pSchool = $_POST['pSchool'];
        $pIntake = $_POST['pIntake'];
        $query = "INSERT INTO user (Email,Password,School,Affiliation,Role,Intake,First_Name,Last_Name,Phone, AccessLevel, Register_Date) VALUES('".$Email."', '".$password."', '".$pSchool."', 'Null', 'Student', '".$pIntake."', '".$F_Name."', '".$L_Name."', '".$mobile."','21',CURRENT_TIMESTAMP)";
        if(!mysqli_query($link, $query)){
          $error = "<p>Could not sign you up. Please try again later.</p>";
        }

      }
    }
  }

?>
      <?php include "includes/header.php";?>
    <div class="container-fluid">
  <body>


	<style>
	body{
       background-image: url("Images/ash-grey-6905.PNG")
     }
	</style>
  <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
<!--
            <div>

                <h1 class="logo-name">OPE</h1>

            </div>
-->
          <div id="error"><?php 
          if($error != ""){
            echo '<div class="alert alert-danger" role="alert">'.$error .'</div>';
          }
          ?></div>
        <form method='post'> 
      <div class="form-group row">
          
        <label for="firstName" class="col-sm-2 col-form-label">First Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="firstName" placeholder="Your First Name">
        </div>
      </div>

      <div class="form-group row">
          
        <label for="lastName" class="col-sm-2 col-form-label">Last Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="lastName" placeholder="Your Last Name">
        </div>
      </div>

      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" name="email" placeholder="Enter Your Email">
        </div>
      </div>
     
      <div class="form-group row">
      <label for="password" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" name="password" placeholder="Enter Your Password">
        </div>
      </div>
      
      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Phone Number</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="phNumber" placeholder="Enter Your Phone Number">
        </div>
      </div>

      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">School</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="pSchool" placeholder="Murdoch University">
        </div>
      </div>
      
      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Intake</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="pIntake" placeholder="Enter the Intake">
        </div>
      </div>
      
      
      
    <button type="submit" class="btn btn-primary" name="submit">Register</button>
    <a href="index.php"><button type="button" class="btn btn-danger" name="cancel">Cancel</button></a>
    </form>
    </div>
    </div>

   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>