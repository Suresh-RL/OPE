<?php

	$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");


//If login is not authorised, force user to quit from this page
if(!$loginAuthorised){
 header("Location: index.php");   
}else{
    
    $PEmail = $_COOKIE["Email"];
    include('connection.php');
    include('profile_func.php');

}


?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Feedback</title>
    <style>
        body{
          background-image: url("Images/ash-grey-6905.png")
        }
        form{
          background-color: #eef2f5;
          padding: 50px;
          margin: 50px;
          border-radius: 20px;
                  overflow: auto;
            margin-left: auto;
    margin-right: auto;
        }
    </style>
  </head>
  <body>
    <?php
		include("navigation.php");

	?>
    <div class="container">
    <div class="row"></div>
    <div class="col-sm">
    
    <?php include('profile_func.php');?>
    <form> 
    <h2>Account Information</h2>
    <p>
        Review your personal details, and update your e-mail and contact.

    </p>
    <h3>Personal Detail</h3>
    <table class="table">
           
            <tbody>
              <tr>
                <th scope="row">First Name</th>
                  <td><?php if(isset($FN)){echo $FN;}?></td>
              </tr>
              <tr>
                    <th scope="row">Last Name</th>
                    <td><?php if(isset($FN)){echo $LN;}?></td>
              </tr>
              <tr>
                    <th scope="row">Email</th>
                    <td><?php if(isset($FN)){echo $PEmail;}?></td>
                </tr>
                <tr>
                        <th scope="row">Role</th>
                        <td><?php if(isset($FN)){echo $RO;}?></td>
                </tr>
                <tr>
                        <th scope="row">Register Date</th>
                        <td><?php if(isset($FN)){echo $RE;}?></td>
                </tr>
                
           
                <?php 
                    
    $accessLevel = $_COOKIE["accessLevel"];
if(isset($accessLevel)AND $accessLevel>=90 OR $accessLevel<=19){//If access level is high, then display the following content
    //For admin
    echo '<tr>
                        <th scope="row">Affiliation</th>
                        <td>';
    
    if(isset($FN)){echo $AF;}
                   
                   echo '</td>';
                echo '</tr>';
        }
else if(isset($accessLevel)AND $accessLevel>=50){
    //If access level is high, then display the following content
    //For admin
    echo '<tr>
                        <th scope="row">School</th>
                        <td>';
    
    if(isset($SC)){echo $SC;}
                   
                   echo '</td>';
                echo '</tr>'; 
 }
else{
    echo '<tr>
                        <th scope="row">School</th>
                        <td>';
    
    if(isset($SC)){echo $SC;}
                   
                   echo '</td>';
                echo '</tr>'; 
    echo '<tr>
                        <th scope="row">Intake</th>
                        <td>';
    
    if(isset($IN)){echo $IN;}
                   
                   echo '</td>';
                echo '</tr>'; 
    
    
}
    
    

                
                
                ?>
                <tr>
                        <th scope="row">Phone Number</th>
                        <td><?php if(isset($FN)){echo $PH;}?></td>
                </tr>
                
            </tbody>
          </table>
          <td><a href="editProfile.php"><button type="button" class="btn btn-danger btn-sm">Update</button></a></td>
    </form>
    </div>
    </div>
    </div>
    
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>