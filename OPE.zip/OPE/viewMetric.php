<?php
    include("header.php");
    include("navigation.php");
    include("connection.php");
?>

<body>
    <div class="container">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Evaluator</th>
      <th scope="col">Presentation</th>
      <th scope="col">Content</th>
      <th scope="col">Eye Contact</th>
      <th scope="col">Organisation</th>
      <th scope="col">Time</th>
      <th scope="col">Average Score</th>
      <th scope="col">Comment</th>
    </tr>
  </thead>
  <tbody>
  

<?php
if(isset($_GET["p_id"]))
{
    $Pid = $_GET["p_id"];
$query = "SELECT * FROM attendee LEFT JOIN metric on attendee.Email = metric.Email WHERE Presentation_ID = {$Pid}";
$result = mysqli_query($link, $query);
while($row = mysqli_fetch_assoc($result)){
    echo "<tr>";
    echo "<td>{$row['Email']}</td>";
    echo "<td>{$row['Rate_q1']}</td>";
    echo "<td>{$row['Rate_q2']}</td>";
    echo "<td>{$row['Rate_q3']}</td>";
    echo "<td>{$row['Rate_q4']}</td>";
    echo "<td>{$row['Rate_q5']}</td>";
    echo "<td>{$row['AverageScore']}</td>";
    echo "</tr>";
}
}
?>
    </tbody>
    </table>



<?php
    include('footer.php');
?>