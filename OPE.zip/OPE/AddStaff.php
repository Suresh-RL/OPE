

<?php include "includes/adminheader.php";?>
<?php include "connection.php";?> 
<?php
$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
if(!$loginAuthorised){
 header("Location: index.php");   
}
?>
<!--<!DOCTYPE html>-->
<html lang="en">
  <div class="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="AdminStaffConsole.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Add a staff to module</li>
      </ol>
      <div class="row">
        <div class="col-12">
          <h1>Add a staff to module</h1>
        </div> 
         
         <div class="col-md-8">
            
<form method="post" action="AddStaff.php">

<!--


  <div class="form-group">
    <label>Lecturer Name</label>
    <input type="text" class="form-control"  name="modID" required>
  </div>
  <div class="form-group">
    <label>Module ID</label>
    <input type="text" class="form-control" name="modName" required>
  </div>
-->
 <div class="form-group">
<select id="tid" name="tid" class="form-control">

<option value="tid">Trimester</option>
<?php
$sql = "SELECT `name` from `trimester`";
$tid = mysqli_query($link,$sql);
while ($row = mysqli_fetch_array($tid)){
echo "<option value='". $row['name'] ."'>" .$row['name'] ."</option>" ;
}
?>
</select>

</div>

 <div class="form-group">
<select id="lectname" name="lectname" class="form-control">

<option value="lectname">Lecturer Name</option>
<?php
$sql = "SELECT CONCAT (First_Name,' ',Last_Name)as 'lectname',Email from `user` WHERE Role = 'Lecturer'";    
$lectname = mysqli_query($link,$sql);
while ($row = mysqli_fetch_array($lectname)){
echo "<option value='". $row['Email'] ."'>" .$row['Email'] ."</option>" ;
}
?>
</select>

 </div>
 
  <div class="form-group">
<select id= "modid" required name="module_id" class="form-control">

<option  value="module_id">Module ID</option>
<?php
$sql = "SELECT `module_id` from `module` ";
$module_id = mysqli_query($link,$sql);
while ($row = mysqli_fetch_array($module_id)){
echo "<option value='". $row['module_id'] ."'>" .$row['module_id'] ."</option>" ;
}
?>
</select>

 </div>
 
  <button onclick = "createModuleLect()" class="btn btn-primary" name="addStaff">Submit</button>
</form> 

         </div>
      </div>
      
   <script>
   
    function createModuleLect()
       {
//           alert("fun");
//        

           
          var lectName =  $('#lectname').find(":selected").text();
          var moduleid =  $('#modid').find(":selected").text();
          var tid      =  $('#tid').find(":selected").text();
          
//      alert(lectName);
//       alert(moduleid);
//           alert(tid);
           
           if (lectName == '' || moduleid == '' || tid == '') {
             alert("Please Fill All Fields");
               } 
           else
            var lectName =  $('#lectname').find(":selected").text();
            var moduleid =  $('#modid').find(":selected").text();
            var tid      =  $('#tid').find(":selected").text();
                   {  $.ajax( {
                        'url': "data-addmoduleLect.php",
                        'type': 'POST',
//                        'dataType': 'json', 
                        'data': {lectName:lectName,moduleid:moduleid,tid:tid},
                       
                       success: function(html) {
                           
                           alert(html);
//                            $("#message").text(strMessage);
//                            $("#addmodule")[0].reset();
                           
                        }

                        
                    });
                   }
           
                  document.getElementById('lectName').value ="";
                  document.getElementById('moduleid').value ="";
                  document.getElementById('tid').value ="";
//                });
//            }); 
           }
        </script>  
   
   
   
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
<!--          <small>Copyright © Your Website 2018</small>-->
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
  </div>
</body>

</html>
