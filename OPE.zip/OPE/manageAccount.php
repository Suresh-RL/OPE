<?php

$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
$AccessLevelAuthorised = ($_COOKIE["accessLevel"] >= 90);


//If login is not authorised, force user to quit from this page
if(!$loginAuthorised OR !$AccessLevelAuthorised){
 header("Location: index.php");   
}


if(isset($_GET['delete'])){
    
    $userID = $_GET['delete'];
    include('connection.php');
    $DSQL = "DELETE FROM user WHERE Email = '".$userID."'";
    $DeleteQuery = mysqli_query($link, $DSQL);
    if($DeleteQuery){
         
     echo "Deleted";  
        header("Location: manageAccount.php");
    }
    else{
     echo "Deletion unsuccessful ";   
        echo $DSQL;
    }
    
    
    
    
}



?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Presentation List</title>
    <style>
         body{
         
        }
      
    </style>
  </head>
  <body>
    <div class="container">
    <div class="col-10">
    <h1>Manage Account</h1>
    
    <?php

    include('connection.php');
    
    if($link){
        
        $ListSQL ="SELECT * FROM user";
        
        $ListQuery = mysqli_query($link, $ListSQL);
        
        $indx = 0;
        while($row = mysqli_fetch_assoc($ListQuery)){
            
            $UserList[$indx]['Email'] = $row['Email'];
            $UserList[$indx]['First_Name'] = $row['First_Name'];
            $UserList[$indx]['Last_Name'] = $row['Last_Name'];    
            $UserList[$indx]['School'] = $row['School'];
            $UserList[$indx]['Intake'] = $row['Intake'];    
            $UserList[$indx]['Phone'] = $row['Phone'];    
            $UserList[$indx]['Affiliation'] = $row['Affiliation'];    
            $UserList[$indx]['Role'] = $row['Role'];    
            $UserList[$indx]['Register_Date'] = $row['Register_Date'];    
            
            
            $indx++;
        }
        
        $numUser = sizeof($UserList);
        
        //mysql_free_result(ListQuery);
        
            echo '<table class="table">
        <thead>
          <tr>
            <th scope="col">Email</th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>
            <th scope="col">School</th>
            <th scope="col">Intake</th>
            <th scope="col">Role</th>
            <th scope="col">Phone No</th>
            <th scope="col">Affiliation</th>
            <th scope="col">Registeration Date</th>
          </tr>
        </thead>
        <tbody>';
        
        for($indx = 0;$indx<$numUser;$indx++){
        
          echo '<tr>
            <td>'.$UserList[$indx]['Email'].'</td>
            <td>'.$UserList[$indx]['First_Name'].'</td>
            <td>'.$UserList[$indx]['Last_Name'].'</td>
            <td>'.$UserList[$indx]['School'].'</td>
            <td>'.$UserList[$indx]['Intake'].'</td>
            <td>'.$UserList[$indx]['Role'].'</td>
            <td>'.$UserList[$indx]['Phone'].'</td>
            <td>'.$UserList[$indx]['Affiliation'].'</td>
            <td>'.$UserList[$indx]['Register_Date'].'</td>
            <td><a href="manageAccount.php?delete='.$UserList[$indx]['Email'].'"><button type="button" class="btn btn-danger btn-sm">Delete</button></a></td>
          </tr>';
                              

        }
        echo'</tbody>
      </table>
      <td><a href="menu.php"><button type="button" class="btn btn-danger btn-sm">Return</button></a></td>';
        }
  
    ?>
    
    
    
      </div>
      </div>

  <!-- Modal -->
<div class="modal fade" id="email" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Send email to more attendees</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                    <form>
                            <div class="form-group">
                              <label for="emailAddress">Email address</label>
                              <input type="email" class="form-control" id="emailAddress" placeholder="name@example.com">
                            </div>
                    </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success">Send</button>
            </div>
          </div>
        </div>
      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>