<?php include "connection.php";?>
<?php
header('Content-Type: application/json');
$post= $_POST['post'];

$sqlQuery = "SELECT Module_Name,Grade FROM `presentation` WHERE Presenter_Email = '$post' and Status='Completed'";

$result = mysqli_query($link,$sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($link);

echo json_encode($data);
?>