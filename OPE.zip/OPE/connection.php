<?php

$link = mysqli_connect("localhost", "ope@localhost", "Po827128*","ope_db");
if(mysqli_connect_error()){
    die("There was some connection erorr");
}
?>