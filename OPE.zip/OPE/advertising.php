<?php

$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
$AccessLevelAuthorised = ($_COOKIE["accessLevel"] >= 20);
$P_Email = ($_COOKIE["Email"]);

//If login is not authorised, force user to quit from this page
if(!$loginAuthorised OR !$AccessLevelAuthorised){
 header("Location: index.php");   
}

if(isset($_GET['send'])){
    $status = $_GET['send'];
    
    if($status = "ok"){
        echo '<script>alert("Invitation email is sent!");</script>';
        //header("Location: advertising.php");   
        
    }
   
}




?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Presentation List</title>
    <style>
         body{
          background-image: url("Images/ash-grey-6905.png")
        }
        .container{
          background-color: #eef2f5;
          padding: 50px;
          margin: 50px;
          border-radius: 20px;
        }
    </style>
  </head>
  <body>
    <div class="container">
    <div class="col-10">
    <h1>Advertising of Presentation</h1>
    
    <?php

    include('connection.php');
    //$user_query = "SELECT First_Name, Last_Name, School, Intake, Phone, Affiliation, Role, Register_Date FROM user WHERE Email = '".$PEmail."'";
    if($link){
        
        $ListSQL =" SELECT * FROM presentation WHERE Presenter_Email = '".$P_Email."'";
        
        $ListQuery = mysqli_query($link, $ListSQL);
        
        $indx = 0;
        
        while($row = mysqli_fetch_assoc($ListQuery)){
            
            $PList[$indx]['Name'] = $row['Name'];
            $PList[$indx]['Status'] = $row['Status'];    
            $PList[$indx]['Module'] = $row['Module_Name'];
            $PList[$indx]['Team'] = $row['Group_Name'];        
            $PList[$indx]['PID'] = $row['Presentation_ID'];   
            $indx++;
            
        }
        if($indx!=0){
        $numUser = sizeof($PList);
        }
        else{
            $numUser = 0;
        }
        //mysql_free_result(ListQuery);
        
            echo '<table class="table">
        <thead>
          <tr>
            <th scope="col">Presentation Name</th>
            <th scope="col">Status</th>
            <th scope="col">Module</th>
            <th scope="col">Team</th>
          </tr>
        </thead>
        <tbody>';
        
        for($indx = 0;$indx<$numUser;$indx++){
         if($PList[$indx]['Status']=="Upcoming"){
          echo '<tr>
            <td>'.$PList[$indx]['Name'].'</td>
            <td>'.$PList[$indx]['Status'].'</td>
            <td>'.$PList[$indx]['Module'].'</td>
            <td>'.$PList[$indx]['Team'].'</td>
            <td><a href="PresentationDetail.php?id='.$PList[$indx]['PID'].'"><button type="button" class="btn btn-danger btn-sm">Detail</button></a></td>';
            
            echo '<td><a href="Email_Invitation.php?id='.$PList[$indx]['PID'].'"><button type="button" class="btn btn-danger btn-sm">Invite</button></a></td>
          </tr>';
            
        }
        }
        echo'</tbody>
      </table>
      <td><a href="menu.php"><button type="button" class="btn btn-danger btn-sm">Return</button></a></td>';
        }
  
    ?>
    
    
    
      </div>
      </div>

  <!-- Modal -->
<div class="modal fade" id="email" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Send email to more attendees</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                    <form>
                            <div class="form-group">
                              <label for="emailAddress">Email address</label>
                              <input type="email" class="form-control" id="emailAddress" placeholder="name@example.com">
                            </div>
                    </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-success">Send</button>
            </div>
          </div>
        </div>
      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>