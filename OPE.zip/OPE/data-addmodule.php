<?php include "connection.php";?>
<?php
// header('Content-Type: application/json');
$modID = $_POST['modID'];
$moduleName = $_POST['moduleName'];

 $sql="INSERT INTO `module`(`Module_ID`, `Module_Name`) VALUES ('$modID','$moduleName')";
 $chkexistquery = mysqli_query($link,"SELECT * FROM `module` where `Module_ID`='$modID' AND `Module_Name` = '$moduleName'");

if(mysqli_num_rows($chkexistquery) > 0) {

        echo "The module already exists.";
    }
    elseif(!mysqli_query($link,$sql)) {
       echo 'Error -Could not insert';

    }
    else {
     echo "Module is added";
    }
 
    //Close connection
    mysqli_close($link);
 // echo json_encode($message);

?>