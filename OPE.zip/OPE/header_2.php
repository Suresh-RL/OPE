<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

    <title>PresentApp</title>
    <style>
     
        /* body{
          background-image: url("Images/background.jpg")
        } */
        form{
          padding: 50px;
          margin: 50px;
          border-radius: 20px;
        }
        #search{
          width:350px;
        }
        a{
      color: inherit;
    }
    #resetPassword{
      display: none;
      
    }
    #profile{
        display: none;
    }
    #modalInput{
      width:70%;
      margin: auto;
      margin-bottom: 20px;
    }
    #mainList{
        background-color: #eef2f5;
          padding: 50px;
          margin: 50px;
          border-radius: 20px;
     }
    </style>
     <script>
   
   $(document).ready(function() {
    var calendar = $('#calendar').fullCalendar({
     editable:true,
     header:{
      left:'prev,next today',
      center:'title',
      right:'month,agendaWeek,agendaDay'
     },
     events: 'load.php',
     selectable:true,
     selectHelper:true,
        
        eventClick:function(event)
     {
      
       var id = event.id;
       window.location.href="PresentationDetail.php?id="+id;//GET method
       
     },
     
 
 
 
    });
   });
    
   </script>
  </head>