<?php


if(isset($_POST['submit'])){
    
    $fname = $_POST['firstName'];
    $lname = $_POST['lastName'];
    $mobileNum = $_POST['Mobile'];
    
    $accessLevel = $_COOKIE["accessLevel"];
    if(isset($accessLevel)AND $accessLevel>=90 OR $accessLevel<=19){
        $affiliation = $_POST['Affiliation'];
        echo $affiliation;
        
        
    }else{
        $School = $_POST['School'];
        echo $School;
    }
    echo $fname;
    echo $lname;
    echo $mobileNum;
   
    include('connection.php');
   
    $CEmail = $_COOKIE["Email"];
    
        //Get information from database
       // $user_SQLselect = "SELECT password, AccessLevel FROM user WHERE Email = '".$email."'";
       // $login_query = mysqli_query($connection, $user_SQLselect);
     $query = "UPDATE `user` SET `Phone` = '".$mobileNum."' WHERE `user`.`Email` = '".$CEmail."'";
     $update_query = mysqli_query($link, $query);
    if($query){
        echo "Update mobile ok ";
    }
     $query = "UPDATE `user` SET `First_Name` = '".$fname."' WHERE `user`.`Email` = '".$CEmail."'";
     $update_query = mysqli_query($link, $query);
    if($query){
        echo "Update first name ok ";
    }
     $query = "UPDATE `user` SET `Last_Name` = '".$lname."' WHERE `user`.`Email` = '".$CEmail."'";
     $update_query = mysqli_query($link, $query);
    if($query){
        echo "Update last name ok ";
    }
     if(isset($accessLevel)AND $accessLevel>=90 OR $accessLevel<=19){
         $query = "UPDATE `user` SET `Affiliation` = '".$affiliation."' WHERE `user`.`Email` = '".$CEmail."'";
         $update_query = mysqli_query($link, $query);
     }
    else{
        $query = "UPDATE `user` SET `School` = '".$School."' WHERE `user`.`Email` = '".$CEmail."'";
        $update_query = mysqli_query($link, $query);
    }
    if($query){
        echo "Update school or affiliation ok ";
    }
    echo "update ok";
}

?>
