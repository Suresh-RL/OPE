<?php
  $loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
$AccessLevelAuthorised = ($_COOKIE["accessLevel"] >= 20);

//If login is not authorised, force user to quit from this page
if(!$loginAuthorised OR !$AccessLevelAuthorised){
 header("Location: index.php");   
}


  include("header.php");
  include("connection.php");
  



  $error = "";
  if(array_key_exists('submit', $_POST)){
    if(!$_POST['title']){
      $error .= "Please give title for your presentation<br>";
    }
    if(!$_POST['venue']){
        $error .= "Please type venue of the presentation<br>";
    }
    if(!$_POST['stime']){
        $error .= "Please select the start time for the presentation<br>";
    }
      if(!$_POST['etime']){
        $error .= "Please select the end time for the presentation<br>";
    }
    if(!$_POST['date']){
        $error .= "Please select the date for the presentation<br>";
    }
    if(!$_POST['presenter1']){
        $error .= "Please add in at least one more presenter<br>";
    }
    if($error !=""){
      $error = "<p> There are a few errors in this form:<p>".$error;
    }else{

      $title = $_POST['title'];
      $description = $_POST['description'];
      $Module = $_POST['module'];
      $school = $_POST['school'];
      $groupName = $_POST['group_name'];
      $venue = $_POST['venue'];
      $stime = $_POST['stime'];
      $etime = $_POST['etime'];
      $date = $_POST['date'];
      $presenter = array();
      for($i=1; $i<=5; $i++){
        if($_POST['presenter'.$i]){
            $presenter[] .=  $_POST['presenter'.$i];
        }
      }
   
    
    


    $start = new DateTime(''.$date.' '.$stime.'');
    $str = $start->format('Y-m-d H:i:s');
    $end = new DateTime(''.$date.' '.$etime.'');
    $e = $end->format('Y-m-d H:i:s');  
        
        
        
        $num = 0;

        $check = "SELECT * FROM presentation WHERE Location = '".$venue."' AND Status = 'Upcoming'";
        $result = mysqli_query($link, $check);
            while($row = mysqli_fetch_assoc($result)){
              $startTime = $row['start'];
              $endTime = $row['end'];
                
                if($str < $endTime AND $e > $startTime){
                 
                   $num = 1;
                    break; 
                }
              

            }
        if($num==0){
          
        $Email = ($_COOKIE["Email"]);
      $query = "INSERT INTO presentation(Group_Name,Presenter_Email,Module_Name, Detail,Grade,Count,School,Status,Name,start,end,Location) VALUES ('$groupName','".$Email."','".$Module."','".$description."','Null','0','".$school."','Upcoming','".$title."','".$str."','".$e."','".$venue."')";
      $result1 = mysqli_query($link, $query);
      if($result1){
     
      $p_query = "SELECT Presentation_ID FROM presentation WHERE Presenter_Email = '".$Email."' AND start = '".$str."' AND Location = '".$venue."'";
     
      $result2 = mysqli_query($link, $p_query);
      if($result2){
        //echo "result 2 ok";
        if ($row = mysqli_fetch_assoc($result2)){
            $p_id = $row['Presentation_ID'];
            //echo $p_id;
        }

        foreach($presenter as $value){
            $insert_group = "INSERT INTO group_presentation(S_Email, Presentation_ID, Grade) VALUES ('{$value}','{$p_id}','NULL')";
            mysqli_query($link,$insert_group);
        }
          echo '<script>alert("Created the group event!");</script>';
              //header("Location: calendar.php");  
          header("Refresh:0");
      

      }


      }
      
      
      

        
        }else{
         $error.="Schedule conflict";   
        }
        
    }
  }
?>
  <body>
   <?php
		include("navigation.php");

	?>
   <style>
	body{
       background-image: url("Images/ash-grey-6905.png")
     }
	</style>
    <div class="container mainBody">
   
    <div class="col-10">
    <form method="post"> 
    <div id="error"><?php 
          if($error != ""){
            echo '<div class="alert alert-danger" role="alert">'.$error .'</div>';
          }
          ?></div>
      <div class="form-group row">
          
        <label for="title" class="col-sm-2 col-form-label">Title</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="title" name="title" placeholder="Presentation Title">
        </div>
      </div>
      <div class="form-group row">
        <label for="Description" class="col-sm-2 col-form-label">Brief Description</label>
        <div class="col-sm-10">
          <textarea type="text" class="form-control" name="description" id="Description" placeholder="Brief Description of Presentation"></textarea>
        </div>
      </div>
    
       <div class="form-group row">
          
        <label for="title" class="col-sm-2 col-form-label">Module</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="title" name="module" placeholder="Module ID">
        </div>
      </div>
      <div class="form-group row">
      <label for="group_name" class="col-sm-2 col-form-label">Group Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="group_name" name="group_name" placeholder="Your Group Name">
        </div>
      </div>
  

      <div class="form-group row">
          
        <label for="presenters" class="col-sm-2 col-form-label">Presenters</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="presenters" name="presenter1" placeholder="Presenter 1">
          <input type="text" class="form-control" id="presenters" name="presenter2" placeholder="Presenter 2">
          <input type="text" class="form-control" id="presenters" name="presenter3" placeholder="Presenter 3">
          <input type="text" class="form-control" id="presenters" name="presenter4" placeholder="Presenter 4">
          <input type="text" class="form-control" id="presenters" name="presenter5" placeholder="Presenter 5">
        </div>
      </div>

       <div class="form-group row">
          
        <label for="school" class="col-sm-2 col-form-label">School</label>

    <div class="form-group col-sm-10">
    <select class="form-control" id="school" name="school">
      <option>School of Arts</option>
      <option>School of Business & Governance</option>
      <option>School of Education</option>
      <option>School of Engineering & Interformation Technology</option>
      <option>School of Health Professions</option>
      <option>School of Law</option>
      <option>School of Psychology & Exercise Science</option>
      <option>School of Veterinary & Life Science</option>
      <option>School of Public Policy & International Affairs</option>

    </select>
  </div>
</div>

<div class="form-group row">
          
          <label for="venue" class="col-sm-2 col-form-label">Venue</label>
  
      <div class="form-group col-sm-10">
      <select class="form-control" id="venue" name="venue">
      <?php
      $L_query = "SELECT * FROM location";
      $L_result = mysqli_query($link, $L_query);
      while($L_row=mysqli_fetch_assoc($L_result)){
        $room = $L_row['Location'];
        echo '<option value="'.$room.'">'.$room.'</option>';
      }

 
  ?>
      </select>
    </div>
  </div>
  
            <div class="form-group row">
                <label for="time" class="col-sm-2 col-form-label">Start Time</label>
                <div class="col-sm-10">
                  <input type="time" class="form-control" name="stime" id="time" placeholder="Time">
                </div>
              </div>
              
              <div class="form-group row">
                <label for="time" class="col-sm-2 col-form-label">End Time</label>
                <div class="col-sm-10">
                  <input type="time" class="form-control" name="etime" id="time" placeholder="Time">
                </div>
              </div>

              <div class="form-group row">
                  <label for="date" class="col-sm-2 col-form-label">Date</label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control" name="date" id="date" placeholder="Date">
                  </div>
                </div>
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                <a href="Menu.php"><button type="button" class="btn btn-danger" name="cancel">Cancel</button></a>
    </form>
    </div>
    </div>

   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <script type="text/javascript">
  
    </script>
  </body>
</html>