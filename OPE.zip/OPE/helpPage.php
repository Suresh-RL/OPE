 <?php

if(array_key_exists('submit', $_POST)){
    include("connection.php");
    
    if($link){
        $s1 = $_POST['s1'];
        $m1 = $_POST['m1'];
        $p1 = $_POST['p1'];
        $y1 = $_POST['y1'];
        $Presenter_Name = $_POST['p1'];
    }
    $error = "";
     if(!$_POST['s1']){
      $error .= "Subject title is required<br>";
    }
    if(!$_POST['m1']){
      $error .= "Please leave the problem description<br>";
    }
    if(!$_POST['p1']){
        $error .= "Email is empty<br>";
    }
    if($error!=""){
      $error = "<p> There are a few errors in this form:<p>".$error;
        echo '<script>alert("'.$error.'");</script>';
    }else{
    
      $headers  = 'From: onlinepresentationevaluator@gmail.com' . "\r\n" .
            'MIME-Version: 1.0' . "\r\n" .
            'Content-type: text/html; charset=utf-8';
        
        $message = "Received a query from user.<br><br>User email: ".$y1."<br>Mobile number: ".$p1."<br>Problem description: ".$m1."<br><br>This is an auto-generated message, please do not reply.";  
        
        //$to = "sysadmin1@murdoch.com";
        $to = "chunkit8328@gmail.com";
if(mail($to, $s1, $message, $headers)){
    echo '<script>alert("Your email is sent to our system administrator");</script>';
    //header("Location: advertising.php?send=ok");
    header("Refresh:0");
}
        else{
            header("email_error.php");
        }
        
    }
    }//end e
    
    




?>




<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Help page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
<style>
      .t1{
      font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  text-align: right;
          
      }
      
      </style>
     
      
  </head>

  <body>
<?php

include('navigation.php');

?>

      <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3"></h1>
   <div class="col-10">
    <h1>Seeking for help?</h1>
       <p> If you encounter any issue in using the website, please do not hestitate to contact our system administrator by sending an email with the form provided below. </p>
    <form method="post"> 

      <div class="form-group row">
          
        <label for="title" class="col-sm-2 col-form-label">Subject</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="s1" name="s1" placeholder="The email subject">
        </div>
      </div>

       
    <div class="form-group row">
            <label for="presenters" class="col-sm-2 col-form-label">Message</label>
            <div class="col-sm-10">
              <input type="text" multiple class="form-control" id="m1" name="m1" placeholder="Leave the problem description">
            </div>
          </div>
      
      <div class="form-group row">
          <label for="attendees" class="col-sm-2 col-form-label">Your Email</label>
          <div class="col-sm-10">
            <input type="email" multiple class="form-control" id="y1" name="y1" placeholder="Leave your Email here">
          </div>
        </div>
              
               <div class="form-group row">
            <label for="presenters" class="col-sm-2 col-form-label">Mobile number</label>
            <div class="col-sm-10">
              <input type="text" multiple class="form-control" id="p1" name="p1" placeholder="Leave your mobile number">
            </div>
          </div>
               
                <br><button type="submit" class="btn btn-primary" name="submit">Send Email</button>
       
                <td><a href="index.php"><button type="button" class="btn btn-primary">Return</button></a></td>

    </form>
    </div>
   
   
    </div>
    <!-- /.container -->

   
   
   
   </div>
   
  
 


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

  </body>

</html>