<?php

	$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");


//If login is not authorised, force user to quit from this page
if(!$loginAuthorised){
 header("Location: index.php");   
}else
{
 $PEmail = $_COOKIE["Email"];   
}



   $error = "";
  if(array_key_exists('submit', $_POST)){
    if(!$_POST['firstName']){
      $error .= "Please give your first name<br>";
    }
    if(!$_POST['lastName']){
      $error .= "Please give your last name<br>";
    }
    if(!$_POST['Mobile']){
        $error .= "Please give your phone number<br>";
    }
  }
      if($error !=""){
      echo "<p> There are a few errors in this form:<p>".$error;
    }else{
          include('edit_profile_func.php');
          if(array_key_exists('update', $_GET)){
          echo '<script>alert("Profile updated!");</script>';
         
          }
      }
  
?>

<!--
<!doctype html>
<html lang="en">
  <head>
-->
    <!-- Required meta tags -->
<!--
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
-->

    <!-- Bootstrap CSS -->
<!--    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">-->

    <title>PresentApp</title>
    <style>
        
        body{
          background-image: url("Images/ash-grey-6905.png")
        }
 
        
        #search{
          width:350px;
        }
    </style>
  </head>
  <body>
    <?php
//    include("includes/navigation.php");
      
        include('connection.php');
        include('profile_func.php');
	?>
      <?php include "includes/header.php";?>
    <div class="container mainBody" >
    <div class="col-10">
    <form action="editProfile_lect.php?update=ok" method="post" ><form> 

      <div class="form-group row">
          
        <label for="firstName" class="col-sm-2 col-form-label">First Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="firstName" value="<?php if(isset($FN)){echo $FN;}?>">
        </div>
      </div>

      <div class="form-group row">
          
        <label for="lastName" class="col-sm-2 col-form-label">Last Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="lastName" value="<?php if(isset($FN)){echo $LN;}?>">
        </div>
      </div>

      
      <div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Phone Number</label>
        <div class="col-sm-10">
          <input type="number" class="form-control" name="Mobile" value="<?php if(isset($FN)){echo $PH;}?>">
        </div>
      </div>

       <?php 
    $accessLevel = $_COOKIE["accessLevel"];
if(isset($accessLevel)AND $accessLevel>=90 OR $accessLevel<=19){//If access level is high, then display the following content
    //For admin
    echo '<div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">Affiliation</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="Affiliation" value="'.$AF.'">
        </div>
      </div>';
        }
else {
    echo '<div class="form-group row">
      <label for="email" class="col-sm-2 col-form-label">School</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="School" value="'.$SC.'">
        </div>
      </div>';
    
}
?>


    <button type="submit" name= "submit" class="btn btn-danger btn-sm">Update</button>
          <a href="Menu.php"><button type="button" class="btn btn-danger btn-sm" name="return">Return</button></a>
    </form>
    </div>
    </div>

   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
  </body>
</html>