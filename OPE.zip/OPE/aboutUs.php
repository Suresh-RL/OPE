<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Modern Business - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
<style>
      .t1{
      font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  text-align: right;
          
      }
      
      </style>
  </head>

  <body>
<?php

include('navigation.php');

?>

    <!-- Page Content -->
    <div class="container">

      <!-- Page Heading/Breadcrumbs -->
      <h1 class="mt-4 mb-3">About Us
        
      </h1>


      <!-- Intro Content -->
      <div class="row">
        <div class="col-lg-6">
          <img class="img-fluid rounded mb-4" src="Images/Presentation.jpg" alt="">
        </div>
        <div class="col-lg-6">
          <h2>About Online Presentation Evaluator</h2>
          <p>Presentation skill is an important aspect to be developed during the education. Employers often
look for this skill when they hire the students along with the technical skill set. Often, the unit
presentations by the student are assessed using paper and that creates the complexity in
analyzing the student’s presentation skills over the time. </p>
          <p>It is also possible that these paper-based
data can be lost. A lot of efforts required from the Admin staffs and teachers to store these data
electronically. Any data analysis on these data would requires additional knowledge and effort.
This leads to the need of a software system that can takes the input from the users and then store
the data for the future information serving purpose. The goal of this project is to develop a web-
based software to track the student presentation details and the feedback.</p>
          <p>The information system allows student to self- register in the OPE system. This allows the
student to be assessed by other teaching staffs and administrators. The initial procedure is when
the student invites the assessors to assess his/her presentation. Assessors can then register to
attend the event to assess a particular student. The feedback on the student’s performance is
keyed in by the assessors on the online system and outputs the overall student performance in
Information serving mode for the particular presentation.</p>
        </div>
      </div>
      <!-- /.row -->

      <!-- Team Members -->
      <h2>Our Team</h2>
      <p>Kindly contact with our team members if you have any issue in using our system.</p>
  
      <div class="row">
        <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Shanith Manoli</h4>
              <h6 class="card-subtitle mb-2 text-muted">Project Team leader</h6>
                <p class="card-text">Oversee the team project and progression<br>Assist the project development<br>Assist in documentation</p>
            </div>
            
            <div class="card-footer">
              <a href="#">shanithlm@gmail.com</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Darryljeet Singh Golan</h4>
              <h6 class="card-subtitle mb-2 text-muted">Database designer lead</h6>
              <p class="card-text">Time tracker for any assignment timeline<br>Design and create database<br>Assist in design workflow</p>
            </div>
            <div class="card-footer">
              <a href="#">darryl@hotmail.com</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Aye Kaung Mya Phyu</h4>
              <h6 class="card-subtitle mb-2 text-muted">Webpage designer lead</h6>
              <p class="card-text">Create GUI of the system<br>Assist in development process<br>Assist in documentation</p>
            </div>
            <div class="card-footer">
              <a href="#">akmphyu@gmail.com</a>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Ong Jing Kai</h4>
              <h6 class="card-subtitle mb-2 text-muted">Documentation lead</h6>
              <p class="card-text">Leading in Infrastructure<br>Assist in documentation<br>Liaise with client</p>
            </div>
            <div class="card-footer">
              <a href="#">ong_kai@gmail.com</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Kwan Chun Kit</h4>
              <h6 class="card-subtitle mb-2 text-muted">Software designer lead</h6>
              <p class="card-text">Assist in development process<br>Assist in design workflow diagram<br>Assist in documentation</p>
            </div>
            <div class="card-footer">
              <a href="#">justicejus91@gmail.com</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Koh Chan Wen</h4>
              <h6 class="card-subtitle mb-2 text-muted">Software designer</h6>
              <p class="card-text">Assist is development process<br>Assist in drawing workflow diagrams<br>Assist in documentation</p>
            </div>
            <div class="card-footer">
              <a href="#">chanwen1@hotmail.com</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-4">
          <div class="card h-100 text-center">
            <div class="card-body">
              <h4 class="card-title">Suresh s/o Rajagopal</h4>
              <h6 class="card-subtitle mb-2 text-muted">Database designer</h6>
              <p class="card-text">Design and create database<br>Assist in documentation<br>GUI and design consultant</p>
            </div>
            <div class="card-footer">
              <a href="#">sureshrajagopal66@gmail.com</a>
            </div>
          </div>
        </div>
      </div>
      <!-- /.row -->

      <!-- Our Customers -->
      
      <!-- /.row -->

   
    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Online Presentation Evaluator 2019</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

  </body>

</html>
