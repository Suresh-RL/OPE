<?php include "connection.php";?>
<?php
// header('Content-Type: application/json');

$lectName = $_POST['lectName'];
$moduleid = $_POST['moduleid'];
$tid      = $_POST['tid'];
$gettrimester = mysqli_query($link,"Select `Trimester_ID` from `trimester` where `Name` = '$tid'");

$row = $gettrimester->fetch_assoc();
    
   $gettrimesterid = $row['Trimester_ID']; 

 $sql="INSERT INTO `module_lecturer`(`Lecturer_Email`, `M_ID`, `T_ID`) Values ('$lectName','$moduleid',$gettrimesterid)";
 $chkexistquery = mysqli_query($link,"SELECT * FROM `module_lecturer` WHERE `Lecturer_Email`='$lectName' AND `M_ID` ='$moduleid' AND `T_ID` =$gettrimesterid");

if(mysqli_num_rows($chkexistquery) > 0) {

        echo "The association already exists.";
    }
    elseif(!mysqli_query($link,$sql)) {
       echo 'Could not insert';

    }
    else {
     echo "Teacher is added to module";
    }
 
    //Close connection
    mysqli_close($link);
 // echo json_encode($message);

?>