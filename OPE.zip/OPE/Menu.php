<?php

	$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");


//If login is not authorised, force user to quit from this page
if(!$loginAuthorised){
 header("Location: index.php");   
}


?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PresentApp</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
       

       a {
    color: inherit;

}
    body{
       background-image: url("Images/ash-grey-6905.PNG")
     }
     #mainList{
        background-color: #eef2f5;
          padding: 50px;
          margin: 50px;
          border-radius: 10px;
         overflow: auto;
            margin-left: auto;
    margin-right: auto;
         
     }
    </style>
  </head>
    <!-- Navigation -->
    

    <body>
     <?php
		include("navigation.php");

	?>
    
    <div class="container" id="mainList">
    
    <h1>Welcome to OPE System</h1>
     <table class="table" >
     <thead>
     <tr>
      <th scope="col"><a href="Profile.php">Personal Information</a></th>
    </tr>
     <?php 
    $accessLevel = $_COOKIE["accessLevel"];
if(isset($accessLevel)AND $accessLevel>=90){//If access level is high, then display the following content
    //For admin
//    echo '<tr>
//      <th scope="col"><a href="editProfile.php">Edit Profile</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="manageAccount.php">Manage Accounts</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="presentationRecord.php">Presentation Attendance Record</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="registerForLecturer.php">Register for lecturer</a></th>
//    </tr>
//
//    <tr>
//      <th scope="col"><a href="index.php?status=logout">Log Out</a></th>
//    </tr>';
    header("Location: AdminStaffConsole.php");  
        }
else if(isset($accessLevel)AND $accessLevel>=50){
    //for lecturer
//    echo '<tr>
//      <th scope="col"><a href="editProfile.php">Edit Profile</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="presentationRecord.php">Presentation Attendance Record</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="viewStatistic.html">Students Performance</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="registerForStudent.php">Register for students</a></th>
//    </tr>
//    <tr>
//      <th scope="col"><a href="index.php?status=logout">Log Out</a></th>
//    </tr>';
  header("Location: TeacherConsole.php"); 
}
else if(isset($accessLevel)AND $accessLevel>=20){
    //for student
    echo'<tr>
      <th scope="col"><a href="editProfile.php">Edit Profile</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="createIndividualPresentation.php">Create Individual Presentation</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="createGroupPresentation.php">Create Group Presentation</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="advertising.php">Advertising of Presentation</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="presentationHistory.php">Presentation History</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="presentationRecord.php">Presentation Attendance Record</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="StudentPerformance.php">Performance</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="index.php?status=logout">Log Out</a></th>
    </tr>';
}
else
{//for guest
    echo'<tr>
      <th scope="col"><a href="editProfile.php">Edit Profile</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="presentationRecord.php">Presentation Attendance Record</a></th>
    </tr>
    <tr>
      <th scope="col"><a href="index.php?status=logout">Log Out</a></th>
    </tr>';
}
    
        ?>
  </thead>
    </table>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload to Register</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <div class="input-default-wrapper mt-3">

  <input type="file" id="file-with-current" class="input-default-js">


</div>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

    </div> 
       <!-- Footer -->
       <?php
      include('footer.php');
  ?>