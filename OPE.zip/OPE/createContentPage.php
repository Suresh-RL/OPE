<?php
  include("header.php");
  include("connection.php");
  session_start();
  
  $error = "";
  if(array_key_exists('submit', $_POST)){
    if(!$_POST['title']){
      $error .= "Please give title for your presentation<br>";
    }
    if(!$_POST['teamName']){
      $error .= "Please give your team a name<br>";
    }
    if(!$_POST['attendee']){
      $error .= "Please type attendees to invite<br>";
    }
    if(!$_POST['venue']){
        $error .= "Please type venue of the presentation<br>";
    }
    if(!$_POST['time']){
        $error .= "Please select the time for the presentation<br>";
    }
    if(!$_POST['date']){
        $error .= "Please select the date for the presentation<br>";
    }
    if(!$error){
      $error = "<p> There are a few errors in this form:<p>".$error;
    }else{
      $title = $_POST['title'];
      $description = $_POST['description'];
      $teamName = $_POST['teamName'];
      $school = $_POST['school'];
      $type = $_POST['type'];
      $attendee = $_POST['attendees'];
      $presenter = $_POST['presenters'];
      $venue = $_POST['venue'];
      $time = $_POST['time'];
      $date = $_POST['date'];
      $query = "INSERT INTO presentation(Group_Name,Creator,Detail,Grade,Type,School,Status,Title,Venue,Date,Time,Presenters,Attendees) VALUES ('{$teamName}','NULL','{$description}','NULL','{$type}','{$school}','Upcoming','{$title}','{$venue}','{$date}','{$time}','{$presenter}','{$attendee}')";
      if(!mysqli_query($link, $query)){
        $error = "<p>Could not create. please try again later</p>";
      }else{
        echo "Successful";
      }
    }
  }
?>
  <body>
   <?php
		include("navigation.php");

	?>
   <style>
	body{
       background-image: url("Images/ash-grey-6905.png")
     }
	</style>
    <div class="container mainBody">
    <div class="col-10">
    <form method="post"> 
    <div id="error"><?php 
          if($error != ""){
            echo '<div class="alert alert-primary" role="alert">'.$error .'</div>';
          }
          ?></div>
      <div class="form-group row">
          
        <label for="title" class="col-sm-2 col-form-label">Title</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="title" name="title" placeholder="Presentation Title">
        </div>
      </div>
      <div class="form-group row">
        <label for="Description" class="col-sm-2 col-form-label">Brief Description</label>
        <div class="col-sm-10">
          <textarea type="text" class="form-control" name="description" id="Description" placeholder="Brief Description of Presentation"></textarea>
        </div>
      </div>

      <div class="form-group row">
          
        <label for="title" class="col-sm-2 col-form-label">Team Name</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="title" name="teamName" placeholder="Your Team Name">
        </div>
      </div>

       <div class="form-group row">
          
        <label for="school" class="col-sm-2 col-form-label">School</label>

    <div class="form-group col-sm-10">
    <select class="form-control" id="school" name="school">
      <option>School of Arts</option>
      <option>School of Business & Governance</option>
      <option>School of Education</option>
      <option>School of Engineering & Interformation Technology</option>
      <option>School of Health Professions</option>
      <option>School of Law</option>
      <option>School of Psychology & Exercise Science</option>
      <option>School of Veterinary & Life Science</option>
      <option>School of Public Policy & International Affairs</option>

    </select>
  </div>
</div>

      <div class="form-check">
          <input class="form-check-input" type="radio" name="type" id="individual" value="Individual" checked>
          <label class="form-check-label" for="individual">
            Individual Presentation
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="type" id="group" value="Group">
          <label class="form-check-label" for="group">
            Group Presentation
          </label>
        </div>
      <div class="form-group row">
          <label for="attendees" class="col-sm-2 col-form-label">Attendees</label>
          <div class="col-sm-10">
            <input type="email" multiple class="form-control" id="attendees" name="attendees" placeholder="Attendees' Emails">
          </div>
        </div>
        <div class="form-group row">
            <label for="presenters" class="col-sm-2 col-form-label">Presenters</label>
            <div class="col-sm-10">
              <input type="email" multiple class="form-control" id="presenters" name="presenters" placeholder="Presenters' Emails">
            </div>
          </div>
          <div class="form-group row">
              <label for="venue" class="col-sm-2 col-form-label">Venue</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="venue" name="venue" placeholder="Venue">
              </div>
            </div>
            <div class="form-group row">
                <label for="time" class="col-sm-2 col-form-label">Time</label>
                <div class="col-sm-10">
                  <input type="time" class="form-control" name="time" id="time" placeholder="Time">
                </div>
              </div>

              <div class="form-group row">
                  <label for="date" class="col-sm-2 col-form-label">Date</label>
                  <div class="col-sm-10">
                    <input type="date" class="form-control" name="date" id="date" placeholder="Date">
                  </div>
                </div>
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                <a href="Menu.php"><button type="button" class="btn btn-danger" name="cancel">Cancel</button></a>
    </form>
    </div>
    </div>

   
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    <script type="text/javascript">
  
    </script>
  </body>
</html>