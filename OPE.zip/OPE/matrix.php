
<?php
    include("header.php");
    include("navigation.php");
    include("connection.php");
?>
<?php

if(isset($_GET["p_id"])){
    $Pid = $_GET["p_id"];
    $email = $_COOKIE['Email'];
if(isset($_POST['submit'])){
    
    $rateq1 = $_POST['rateq1'];
    $rateq2 = $_POST['rateq2'];
    $rateq3 = $_POST['rateq3'];
    $rateq4 = $_POST['rateq4'];
    $rateq5 = $_POST['rateq5'];
    $comment = $_POST['comment'];

$sql = "INSERT INTO metric (Metric_ID, Comments, Rate_q1, Rate_q2, Rate_q3, Rate_q4, Rate_q5,Email) VALUES ('".$Pid."', '{$comment}','{$rateq1}', '{$rateq2}', '{$rateq3}',  '{$rateq4}', '{$rateq5}','{$email}')";
    

//$result = mysqli_query($link, $sql);

    if(!mysqli_query($link, $sql)) {
        
        //die('query Failed' .mysqli_error());
        echo "error";
        echo mysqli_error($link);
    }else{
    $feedback_user = "UPDATE attendee SET Status = 'Submitted' WHERE Presentation_ID='".$Pid."' AND Email = '".$email."'"; 
    $feedback_query = mysqli_query($link, $feedback_user);
    
    echo '<script>alert("Feedback is given!");</script>';
    }
}
}
?>

<body>
<div class="container">
<br><br>
<?php
    $query = "SELECT * FROM presentation WHERE Presentation_ID={$Pid}";
    $result = mysqli_query($link, $query);
    while($row = mysqli_fetch_assoc($result)){
        echo "<h1>{$row['Name']}</h1>";
        echo "<p>{$row['Detail']}</p>";
    }
?>
 <form action ="" method="post">
  <table width="100%"> 
        <tr><td colspan="5"><h3>Evaluation</h3> 
        Rate the proficiency of presenters in the following areas where: 
        <ul><li>1 = Need Improvement<li>2 = Fair<li>3 = Good<li>4 = Excellent</ul></td></tr> 
        <tr>
        <td>&nbsp;</td>
        <td align="center">1</td>
        <td align="center">2</td>
        <td align="center">3</td>
        <td align="center">4</td>
        <tr><td colspan=5 height=1 bgcolor="black"></td></tr>
        
         <tr><td><label class="label" for="rate_q1">Presentation</label>:</td>
         <td align="center"><input type = "radio" name="rateq1" id="rate_q1_1" value="1" class="radio"/><label class="radiolabel" for="rate_q1_1"></label> </td> 
         <td align="center"><input type = "radio" name="rateq1" id="rate_q1_2" value="2" class="radio"/><label class="radiolabel" for="rate_q1_2"></label> </td> 
         <td align="center"><input type = "radio" name="rateq1" id="rate_q1_3" value="3" class="radio"/><label class="radiolabel" for="rate_q1_3"></label> </td>
         <td align="center"><input type = "radio" name="rateq1" id="rate_q1_4" value="4" class="radio"/><label class="radiolabel" for="rate_q1_4"></label> </td>  </tr>
         <tr><td><label class="label" for="rate_q2">Content</label>:</td>
         <td align="center"><input type = "radio" name="rateq2" id="rate_q2_1" value="1" class="radio"/><label class="radiolabel" for="rate_q2_1"></label> </td> 
         <td align="center"><input type = "radio" name="rateq2" id="rate_q2_2" value="2" class="radio"/><label class="radiolabel" for="rate_q2_2"></label> </td> 
         <td align="center"><input type = "radio" name="rateq2" id="rate_q2_3" value="3" class="radio"/><label class="radiolabel" for="rate_q2_3"></label> </td>
         <td align="center"><input type = "radio" name="rateq2" id="rate_q2_4" value="4" class="radio"/><label class="radiolabel" for="rate_q2_4"></label> </td>  </tr>
         <tr><td><label class="label" for="rate_q3">Eye contact</label>:</td>
         <td align="center"><input type = "radio" name="rateq3" id="rate_q3_1" value="1" class="radio"/><label class="radiolabel" for="rate_q3_1"></label> </td> 
         <td align="center"><input type = "radio" name="rateq3" id="rate_q3_2" value="2" class="radio"/><label class="radiolabel" for="rate_q3_2"></label> </td> 
         <td align="center"><input type = "radio" name="rateq3" id="rate_q3_3" value="3" class="radio"/><label class="radiolabel" for="rate_q3_3"></label> </td>
         <td align="center"><input type = "radio" name="rateq3" id="rate_q3_4" value="4" class="radio"/><label class="radiolabel" for="rate_q3_4"></label> </td>  </tr>
         <tr><td><label class="label" for="rate_q4">Organization</label>:</td>
         <td align="center"><input type = "radio" name="rateq4" id="rate_q4_1" value="1" class="radio"/><label class="radiolabel" for="rate_q4_1"></label> </td>
         <td align="center"><input type = "radio" name="rateq4" id="rate_q4_2" value="2" class="radio"/><label class="radiolabel" for="rate_q4_2"></label> </td> 
         <td align="center"><input type = "radio" name="rateq4" id="rate_q4_3" value="3" class="radio"/><label class="radiolabel" for="rate_q4_3"></label> </td>
         <td align="center"><input type = "radio" name="rateq4" id="rate_q4_4" value="4" class="radio"/><label class="radiolabel" for="rate_q4_4"></label> </td>  </tr>
         <tr><td><label class="label" for="rate_q5">Time</label>:</td>
         <td align="center"><input type = "radio" name="rateq5" id="rate_q5_1" value="1" class="radio"/><label class="radiolabel" for="rate_q5_1"></label> </td> 
         <td align="center"><input type = "radio" name="rateq5" id="rate_q5_2" value="2" class="radio"/><label class="radiolabel" for="rate_q5_2"></label> </td> 
         <td align="center"><input type = "radio" name="rateq5" id="rate_q5_3" value="3" class="radio"/><label class="radiolabel" for="rate_q5_3"></label> </td>
         <td align="center"><input type = "radio" name="rateq5" id="rate_q5_4" value="4" class="radio"/><label class="radiolabel" for="rate_q5_4"></label> </td>  </tr>
          <tr></tr>
           </table>
         <table width="100%">
             <tr><td><label class="textlabel" for="comment">Additional Feedback</label><br><textarea name="comment" id="comment" rows="6" cols="70" class="textarea"></textarea><br></td></tr>
             </table>
         <table width="100%">
             <tr><td align="center"><input type="submit" name="submit" value="submit" class="submit"/></td></tr>
            
        </form>
              
    </table>  
   </div>
<?php
include('footer.php');
?>