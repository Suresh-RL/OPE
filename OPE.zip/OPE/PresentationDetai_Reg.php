<?php

if(isset($_GET["id"]))
{

    $Pid = $_GET["id"];
    $ST = "";
    include('connection.php');


    $PSQL = "SELECT * FROM presentation WHERE Presentation_ID = '".$Pid."'";
    $PQuery = mysqli_query($link, $PSQL);
    if($PQuery){
         
        while($row = mysqli_fetch_assoc($PQuery)){
            $GN = $row['Group_Name'];
            $PE = $row['Presenter_Email'];    
            $MN = $row['Module_Name'];
            $DE = $row['Detail'];    
            $CO = $row['Count'];    
            $SC = $row['School'];    
            $ST = $row['Status'];    
            $NA = $row['Name'];
            $STA = $row['start'];   
            $EN = $row['end'];   
 
        }
    }
    else{
     echo "Unsuccessful ";   
        echo $PSQL;
    }
    
}else
{
     header("Location: index.php");      
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Feedback</title>
    <style>
        body{
          background-image: url("Images/ash-grey-6905.png")
        }
        form{
          background-color: #eef2f5;
          padding: 50px;
          margin: 50px;
          border-radius: 20px;
             overflow: auto;
            margin-left: auto;
    margin-right: auto;
        }
    </style>
  </head>
  <body>
    <?php
		include("navigation.php");

	?>
<!--     <div class="container mainBody">-->
<!--    <div class="container">-->
    <div class="row"></div>
<!--    <div class="col-sm">-->
<!--
      
    <div class="col-10">
-->
    <form> 
    <h2><?php if(isset($NA)){echo $NA;}?></h2>
    <p>
        <?php if(isset($DE)){echo $DE;}?>

    </p>
    <h3>Presentation Status</h3>
    <table class="table">
     
            <tbody>
              <tr>
                <th scope="row">Presentation Status</th>
                <td><?php if(isset($ST)){echo $ST;}?></td>
              </tr>
              <tr>
                    <th scope="row">Presentation Date</th>
                    <td><?php if(isset($STA)){echo $STA;}?> to <?php if(isset($EN)){echo $EN;}?></td>
              </tr>
              <tr>
                    <th scope="row">Main Presenter</th>
                    <td><?php if(isset($PE)){echo $PE;}?></td>
                </tr>
                
                <?php  
                if(isset($_COOKIE["accessLevel"])){
                $accessLevel = $_COOKIE["accessLevel"];
                }
                if((isset($accessLevel)) AND ($accessLevel<=60) AND ($accessLevel>=20) AND ($ST != 'Upcoming')){
                  if(isset($_GET['id'])){
                    $presentation_id = $_GET['id'];
                      $email = $_COOKIE["Email"];

                    $grade_query = "SELECT * FROM attendee WHERE Presentation_ID = {$presentation_id} AND Email ='".$email."'";
          $grade_result =   mysqli_query($link, $grade_query);
          if($g_row = mysqli_fetch_assoc($grade_result)){
            if($g_row['Grade'] != ""){
                  echo '
                <tr>
                        <th scope="row">Grade</th>
                        <td>'.$g_row['Grade'].'</td>
                </tr>
                <tr>
                        <th scope="row">Grade By</th>
                        <td>'.$g_row['Email'].'</td>
                </tr>
               
                <tr>
                        <th scope="row">Feedback by Lecturer</th>
                        <td>'.$g_row['Feedback'].'</td>
                </tr>';
            }
          }  
                 }
                }
                    ?>
            </tbody>
          </table>
          
          
        <?php     
        if(isset($ST)AND $ST=="Upcoming"){ 
            
        ?>
        <?php if(isset($PE) AND isset($_COOKIE["Email"]) AND $PE!=$_COOKIE["Email"]){
        echo '<a href="RegisterToAttend.php?id='.$Pid.'"><button type="button" class="btn btn-danger btn-sm">Register</button></a>';
        }
            ?>
        <?php
        }
        ?>
              <a href="calendar.php"><button type="button" class="btn btn-danger btn-sm">Back to Calendar</button></a>
             
             <a href="Menu.php"><button type="button" class="btn btn-danger btn-sm">Back to Menu</button></a>
              
    </form>
    </div>
    </div>
      </div>

    
        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>