<?php include "includes/adminheader.php";?>
<?php include "connection.php";?>
<?php

	$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");


//If login is not authorised, force user to quit from this page
if(!$loginAuthorised){
 header("Location: index.php");   
}


?>
    
               <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

    <title>PresentApp</title>
    <style>
        
        body{
          background-image: url("Images/ash-grey-6905.png")
        }
        form{
          background-color: #eef2f5;
          padding: 50px;
          margin: 50px;
          border-radius: 20px;
                  overflow: auto;
            margin-left: auto;
    margin-right: auto;
        }
        #search{
          width:350px;
        }
    </style>
  </head>
  <body>           
<!--
 <style type="text/css">
BODY {
    width: 550PX;
}

#chart-container {
    width: 100%;
    height: auto;
}
</style>
-->
<script type="text/javascript" src="custom1/js/jquery.min.js"></script>
<script type="text/javascript" src="custom1/js/Chart.min.js"></script>              
               

          
         
       <style>
select {
    width:150px;
    border:1px solid blue;
    -webkit-border-top-right-radius: 15px;
    -webkit-border-bottom-right-radius: 15px;
    border-top-right-radius: 15px;
    border-bottom-right-radius: 15px;
    padding:2px;
}

</style>
        <!-- Begin Page Content -->
        <div class="container-fluid">
          
          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
          </div>
          <!-- Content Row -->
          <div class="row">

       

          </div>
          <div class="input-group">

    <div class="input-group-append"><label>
     <label for="male" color ="#000000">Student Email</label>
<!--
    Select an option to search for :
    <select name = "searchoption" style="border:none">
        <option>Student Name</option>
-->
<!--        <option>Student ID</option>-->
              
             <input type="text" id="sid"  style="border:none" placeholder="Enter student name" />

<!--              <input type="text" name="studentname" value="<?php echo $studentname;?>" style="border:none" />-->
             
                <button class="btn btn-primary"  onclick= "showGraph()" >
                  <i class="fas fa-search fa-sm"></i>
                </button>
           
           
    </select> 
</label>  </div>  </div>          
 

 <div >

  
    </div>
  

    <script>
         function showGraph()
        {
    
         var post = $('input#sid').val();
        
                
                $.ajax({
                    'url': 'data.php',
                    'type': 'POST',
                    'dataType': 'json', 
                    'data': {post: post},
                    'success': function(data)
                
//                $.post("data.php",
//                function (data)
                {
                    console.log(data);
                     var ModuleName = [];
                    var Grade = [];

                    for (var i in data) {
                        ModuleName.push(data[i].Module_Name);
                        Grade.push(data[i].Grade);
                    }

                    var chartdata = {
                        labels: ModuleName,
                        datasets: [
                            {
                                label: 'Student Grade Chart',
                                 backgroundColor: '#49e2ff',
                               borderColor: '#46d5f1',
                               hoverBackgroundColor: '#CCCCCC',
                               hoverBorderColor: '#666666',
                                fill:false,
                                data: Grade
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var barGraph = new Chart(graphTarget, {
                        type: 'line',
                        data: chartdata
                    });
                }
                });
            
        
                       }
        </script>


                <!-- Card Body -->
<!--
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                </div>
-->
             

      

            

        </div>

        
             

         <div class="col-xl-8 col-lg-7">
<!--              <div class="card shadow mb-4">  -->

          <!-- Content Row -->
          <div class="row">
  <div id="chart-container">
        <canvas id="graphCanvas"  style="position: relative; height:40vh; width:80vw"></canvas>
  
    </div>
            <!-- Content Column -->
            <div class="col-lg-6 mb-4">

        <!-- /.container-fluid -->
                        </div>
                                        </div>
     
      <!-- End of Main Content -->

      <!-- Footer -->
<!--
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
-->
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
