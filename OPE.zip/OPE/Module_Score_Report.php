<?php include "includes/header.php";?>
      <?php include "connection.php";?>  

 <?php

    $title = $_GET['title'];

?>
     
     
          
 <?php
$loginAuthorised = ($_COOKIE["loginAuthorised"] == "valid");
if(!$loginAuthorised){
 header("Location: index.php");   
}
?>  
<style>
#myInput {

  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 12px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}  
    
    </style>
<script src="dist/js/tabulator.min.js"></script>
<script src="dist/js/tabulator.js"></script>
<script src="vendor/excel/xlsx.full.min.js"></script>
<script src="custom1/js/jquery-2.1.1.min.js"></script>

<script>

    $(function() {
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable > tbody > tr").filter(function() {      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

</script>   
     
      
        <!-- Begin Page Content -->
       <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Individual/Group Presentations</h1>
          <p class="mb-4">Individual and Group Presentation details for the module </p>
          
            <div class="card shadow mb-4">
            <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Individual/Group Presentations list - <?php echo $title ?></h6>
                <h10  >Average unit grade : 
                    <?php 
    
    $avgsql = mysqli_query($link,"Select TRUNCATE(AVG(cast(grade AS DECIMAL(10,2))),2) as 'avg' from presentation where Module_Name = '$title'");
    
                $row = $avgsql->fetch_assoc();
    
            $avgscore = $row['avg'];
    echo($avgscore);
    
    ?>
    </h10> 
              <input type="text" id="myInput"  placeholder="Search " title="Type in a name" >
            </div>
            <div class="card-body">
              <div class="table-responsive">
              
<!--<div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="dataTable_length"><label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="dataTable_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable"></label></div></div></div>-->
               
                          
               <div class="table-responsive">
                <table class="table table-bordered"  ;id="dataTable" width="2000%" cellspacing="0" id ="myTable">
                  <thead>
                    <tr>
                      <th>Presentation ID</th>
                      <th>Group Name</th>
                      <th>Student Name</th>
                      <th>Module</th>
                      <th>Details</th>
                      <th>Grade</th>
                    </tr>
                  </thead>
          <?php  
                    
                    if(isset($_GET['title'])){
                        $moduleName = $_GET['title'];
                        $sql = "SELECT Presentation_ID,Group_Name,Presenter_Email,Module_Name,Detail,Grade FROM presentation WHERE Module_Name='".$moduleName."'"; 
                        
                        
                    }else{
                    
                    
                   $sql = "SELECT Presentation_ID,Group_Name,Presenter_Email,Module_Name,Detail,Grade FROM presentation WHERE  Module_Name='0000'";
                    }
            
            $individual_prese_score = mysqli_query($link,$sql);
                    if(!$individual_prese_score){
                        echo $sql;
                    }
                    
            while ($row=mysqli_fetch_assoc($individual_prese_score))
            {
                    $Presentation_ID = $row['Presentation_ID'];
                    $Group_Name = $row['Group_Name'];
					$Presenter_Email = $row['Presenter_Email'];
					$Module_Name = $row['Module_Name'];
					$Detail = $row['Detail'];
					$Grade = $row['Grade'];
					
					?> 
                  <tbody>
                    <tr>
                      <td><?php echo $Presentation_ID ?></td>
                      <td><?php echo $Group_Name ?></td>
                      <td><?php echo $Presenter_Email ?></td>
                      <td><?php echo $Module_Name ?></td>
                      <td><?php echo $Detail ?></td>
                      <td><?php echo $Grade ?></td>
                    </tr>

                    <?php        
           } ?>
           
                     </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>

   
   
   
<!-- Group Presentation Table-->
<!--
 
 <div class="card shadow mb-4">
            <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Group Presentations list</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
              
<div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="dataTable_length"><label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="dataTable_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable"></label></div></div></div>
               
                          
               <div class="table-responsive">
                <table class="table table-bordered"  ;id="dataTable" width="2000%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Presentation ID</th>
                      <th>Group Name</th>
                      <th>Presentation Name</th>
                      <th>Module</th>
                      <th>Detail</th>
                      <th>Grade</th>
                    </tr>
                  </thead>
          <?php  $sql = "SELECT a.Presentation_ID,CONCAT (b.First_Name,' ',b.Last_Name)as 'stud_name',a.Name,a.Module_Name,a.Detail,a.Grade from presentation a, user b
	            where a.Presenter_Email = b.email"; 
            
            $individual_prese_score = mysqli_query($link,$sql);
                    
            while ($row=mysqli_fetch_assoc($individual_prese_score))
            {
                    $Presentation_ID = $row['Presentation_ID'];
                    $stud_name = $row['stud_name'];
					$Name = $row['Name'];
					$Module_Name = $row['Module_Name'];
					$Detail = $row['Detail'];
					$Grade = $row['Grade'];
					
					?> 
                  <tbody>
                    <tr>
                      <td><?php echo $Presentation_ID ?></td>
                      <td><?php echo $stud_name ?></td>
                      <td><?php echo $Name ?></td>
                      <td><?php echo $Module_Name ?></td>
                      <td><?php echo $Detail ?></td>
                      <td><?php echo $Grade ?></td>
                    </tr>

                    <?php        
           } ?>
           
                     </tbody>
                </table>

          </div>

        </div>
 
-->
  
   
               </div>
        <!-- /.container-fluid -->
   
   
   <!-- End of Main Content -->
         <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
<!--            <span>Copyright &copy; Your Website 2019</span>-->
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

   </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>